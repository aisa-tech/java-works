package uniquecards;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class CreditCardsExample {

	
	public static void main(String[] args) {
		
		ArrayList<String> uniques = new ArrayList<String>();
		ArrayList<String> dublicates = new ArrayList<String>();
		
		try(
				
				BufferedReader reader = new BufferedReader(new FileReader("creditcards.txt"));
				
				)
		{
			
			
			String line ="";
			while((line=reader.readLine())!=null) {
				
					if(uniques.contains(line)) {
						if(!dublicates.contains(line)) {
							dublicates.add(line);
							
						}

						
					}else {
						uniques.add(line);
					}

			}
		
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		
		
		
		System.out.println("Unique count:" + uniques.size());
		System.out.println("Dublicate count:" + dublicates.size());
		
		
		
	}
	
	
	
	
}
