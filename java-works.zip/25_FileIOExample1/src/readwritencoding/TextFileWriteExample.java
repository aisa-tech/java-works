package readwritencoding;


import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;

public class TextFileWriteExample {

	//Plus Encoding
	//Encoding supper reader and writer types: InputStreamReader and OutputStreamWriter
	public static void main(String[] args) {
		
		//After Java 8
		//Autoclosable interface

		//new FileWriter() - > creates file if it doesn't exists, and if it exists it overwrites the content
		//new FileWriter(Path, boolean append) -> append = true => it appends to the file
		
		try (
				
				BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("mytext2.ddc"),"utf-8"));
				
				
				)
			{
			
			String output = "ÇÇŞŞĞĞüüiiİİİİ\nMore and ÇÇööÖÖççÇÇşşİİİİğğüüüÜÜÜ\nmore more more content";

			writer.write(output);
			writer.flush();
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}
	
	
	
	
}
