package readwritencoding;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class TextFileReadExample {

	public static void main(String[] args) {
		
		
		//Reader -> BufferedReader
		
		StringBuilder buffer = new StringBuilder();
		
		
		try (
				BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream("mytext2.ddc"), "utf-8"));
				
				
				){
			
			String line ="";
			while((line = reader.readLine())!=null) {
				//System.out.println(line);
				buffer.append(line + "\n");
			}
			
			
			System.out.print(buffer);
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.out.println("File doesnt exits");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		
	}
	
	
	
	
}
