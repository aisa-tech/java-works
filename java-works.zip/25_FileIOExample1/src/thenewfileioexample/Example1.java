package thenewfileioexample;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

public class Example1 {
//Strictly after Java 8
	
	public static void main(String[] args) {
		
		
		//Paths -> Path
		//Files
		
		//1- Create a Path
		//2- Use Files the path together
		
		
		Path path = Paths.get("mytext.ddc");
		
		//All file operations like exists(), delete, copy are under Files class
		
		try {
			List<String> lines =  Files.readAllLines(path,Charset.forName("utf-8"));
			
			for (String line : lines) {
				System.out.println(line);
			}
			
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	
	
}
