package wordcount;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class WordCountExample {

	
	public static void main(String[] args) {
		
		ArrayList<Integer> counts = new ArrayList<Integer>();
		ArrayList<String> words = new ArrayList<String>();
		
		try(
				
				BufferedReader reader = new BufferedReader(new FileReader("mytext.ddc"));
				
				)
		{
			
			
			String line ="";
			while((line=reader.readLine())!=null) {
				
				String[] parts = line.split(" ");
				
				for (int i = 0; i < parts.length; i++) {
					int idx = words.indexOf(parts[i]);
					if(idx!=-1) {
						
						counts.set(idx, counts.get(idx)+1); 
						
						
					}else {
						words.add(parts[i]);
						counts.add(1);
					}

				}

			}
			
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		
		System.out.println(words);
		System.out.println(counts);
		
		
	}
	
	
	
	
}
