package example2;


import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class TextFileWriteExample {

	
	public static void main(String[] args) {
		
		//After Java 8
		//Autoclosable interface

		//new FileWriter() - > creates file if it doesn't exists, and if it exists it overwrites the content
		//new FileWriter(Path, boolean append) -> append = true => it appends to the file
		
		try (
				
				BufferedWriter writer = new BufferedWriter(new FileWriter(new File("mytext.ddc"),true));
				
				
				)
			{
			
			String output = "More content\nMore and more content\nmore more more content";

			writer.write(output);
			writer.flush();
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}
	
	
	
	
}
