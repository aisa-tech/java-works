package example1;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class TextFileReadExample {

	public static void main(String[] args) {
		
		
		//Reader -> BufferedReader
		
		StringBuilder buffer = new StringBuilder();
		
		BufferedReader reader = null;
		try {
			reader = new BufferedReader(new FileReader(new File("mytext.ddc")));
			
			String line ="";
			while((line = reader.readLine())!=null) {
				//System.out.println(line);
				buffer.append(line + "\n");
			}
			
			
			System.out.print(buffer);
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.out.println("File doesnt exits");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				reader.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		
		
		
	}
	
	
	
	
}
