package example1;


//All legacy IO types are under java.io package
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class TextFileWriteExample {

	
	public static void main(String[] args) {
		
		
		//TextFiles -> Reader and Writer - > BufferedReader and BufferedWriter
		
		//FileReader and FileWriter
		
		//Legacy File type
		
		//Paths:
		//  c://username/MyDocuments/myfile.txt  -> Absolute Path
		// /Users/atanaltay/Desktop/creaditcards.txt  -> Absolute Path
		
		// Path according to execution
		// Suppose code is executing under folder 23_FileIOExample1
		
		// if Path = "test.txt" --> Relative Path -> path according to the xecution folder
		
		
		//Creating file with full path
		
		//File f = new File("/Users/atanaltay/Documents/it524_2020_ws/25_FileIOExample1/test/sample.ddt");
		
		//Creating a file with relative path
		//File f = new File("test/sample.ddt");
		
		//Creating file with full path
		//File f = new File("/Users/atanaltay/Documents/it524_2020_ws/25_FileIOExample1/test.txt")
		
		//Creating a file with relative path
		//File f = new File("test.txt");
		//System.out.println(f.getAbsolutePath());
		
		//How to learn current working directory
		//File f = new File("");
		//System.out.println(f.getAbsolutePath());
		
		//File f2 = new File(f.getAbsolutePath() + "/test.txt");
		//System.out.println(f2.getAbsolutePath());
		
		//if(f2.exists()) System.out.println("File exists");
		//else System.out.println("File doesn't exist");
		
		//Reader and Writer interfaces
		//Reader -> read() ; writer -> write()
		// BufferedReader -> readLine()
		//BufferedWriter -> write()
		
		BufferedWriter writer = null;
		
		try {
			
			String output = "Line 1 content\nLine 2 content\nLine 3 content";
			
			writer = new BufferedWriter(new FileWriter(new File("mytext.ddc")));
			writer.write(output);
			writer.flush();
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				writer.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		
	}
	
	
	
	
}
