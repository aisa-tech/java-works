package q2;

public enum Priority {

	LOW,MEDIUM,HIGH;
}
