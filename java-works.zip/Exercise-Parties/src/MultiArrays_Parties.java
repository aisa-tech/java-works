
import java.util.Arrays;
import java.util.Scanner;

public class MultiArrays_Parties {

	public static void main(String[] args) {

		String[] parties = { "AKP", "ANAP", "AP", "CGP", "CHF", "CHP", "CKMP", "DP", "DSP", "DTP", "DYP", "HDP", "MGP",
				"MHP", "MP", "MSP", "RP", "SHP", "YTP" };

		String[][] dates = new String[][] { { "2002-2020" },
				{ "1961-1962", "1965-1974", "1975-1977", "1977-1978", "1979-1980" },
				{ "1963-1965", "1971-1974", "1978-1979", "2015-2015" }, { "1973-1974", "1975-1977", "1978-1979" },
				{ "1923-1935" }, { "1935-1950", "1971-1973", "1974-1974", "1977-1977", "1978-1979", "1995-1996" },
				{ "1962-1963", "1965-1965" }, { "1950-1960" }, { "1997-2002" }, { "1997-1999" },
				{ "1991-1997", "1996-1997" }, { "2015-2015" }, { "1971-1973" },
				{ "1975-1977", "1977-1978", "1999-2002" }, { "1965-1965" }, { "1974-1974", "1975-1977", "1977-1978" },
				{ "1996-1997" }, { "1991-1995" }, { "1962-1963", "1965-1965" } };

		Scanner sc = new Scanner(System.in);
		System.out.println("Please enter a party");
		String party = sc.nextLine();

		boolean found = false;
		int index = 0;
		for (int i = 0; i < parties.length; i++) {
			if (party.equals(parties[i])) {
				index = i;
				found = true;
			}
		}

		if(found) {

			String[] party_dates = dates[index];

			int sum_rule = 0;
			for (String date_str : party_dates) {
				int begin = Integer.valueOf(date_str.substring(0, 4));
				int end = Integer.valueOf(date_str.substring(5, 9));
				System.out.println(begin);
				System.out.println(end);
				sum_rule += (end - begin + 1);
			}
			System.out.println(party + " ruled for " + sum_rule + " years.");
			
		}else {
			System.out.println("Party name is invalid.");
		}

		

		// Example of getting parts of strings:

		// String dateStr = "2000-2007";
		// int begin = Integer.valueOf(dateStr.substring(0,4));
		// int end = Integer.valueOf(dateStr.substring(5,9));
		// We should include both 2000 and 2007
		// System.out.println("Time elapsed:" + (end-begin+1));

		/*
		 * System.out.println("Please enter a party"); Scanner sc = new
		 * Scanner(System.in); String party = sc.nextLine();
		 * 
		 * boolean found = false; int index =0; for (int i = 0; i < parties.length; i++)
		 * { if(party.equals(parties[i])) { index = i; found = true; } } String tst =
		 * "ali veli";
		 * 
		 * String[] party_dates = dates[index];
		 * 
		 * int sum_rule = 0; for (String date_str : party_dates) { int begin =
		 * Integer.valueOf(date_str.substring(0, 4)); int end =
		 * Integer.valueOf(date_str.substring(5, 9)); sum_rule += (end-begin+1); }
		 * System.out.println(party + " ruled for " + sum_rule + " years.");
		 */
	}

}
