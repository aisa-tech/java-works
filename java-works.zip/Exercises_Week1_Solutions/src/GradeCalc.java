
import java.util.Scanner;

public class GradeCalc {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		System.out.println("Please enter your midterm grade:");
		double midterm = input.nextDouble();
		System.out.println("Please enter your essay grade:");
		double essay = input.nextDouble();
		System.out.println("Please enter your discussion grade:");
		double discussion  = input.nextDouble();
		System.out.println("Please enter your in lecture grade:");
		double in_lecture  = input.nextDouble();
		
		double midterm_w = 0.4;
		double essay_w = 0.3;
		double discussion_w = 0.2;
		double in_lecture_w = 0.1;
		
		double score = midterm*midterm_w +
				essay*essay_w + discussion*discussion_w + in_lecture*in_lecture_w;
		
		if(score>=80) {
			System.out.println("A");
		}else if (score>=60) {
			System.out.println("B");
		}else if (score>=40) {
			System.out.println("C");
		}else System.out.println("F");
		
		
	}
	
	
	
}
