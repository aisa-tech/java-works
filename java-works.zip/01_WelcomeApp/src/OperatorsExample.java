
public class OperatorsExample {

	
	public static void main(String[] args) {
		
		int x1 = 34;
		int x2 = 456;
		
		int sum = x1+x2;
		
		System.out.println("x1 + x2 = " + sum);
		
		String name = "altug";
		String lastname = "tanaltay";
		
		String full_name = name + " " + lastname;
		
		System.out.println(full_name);
		
		System.out.println("altug" + " " + "tanaltay");
		
		//Without paranthesis everything inside the print block will be converted to String
		System.out.println("x1 + x2=" + x1 + x2);
		
		System.out.println("x1 + x2=" + (x1 + x2));
		
		int x3 = 0;
		
		x3++;
		x3++;
		++x3;
		
		System.out.println("x3:" + x3);
		
		//char c23 ="v";
		
		
		
	}
	
	
	
	
}
