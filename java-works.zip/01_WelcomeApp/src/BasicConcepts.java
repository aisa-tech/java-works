
public class BasicConcepts {

	
	public static void main(String[] args) {
		
		
		//this is a single line comment
		
		/*
		  
		  This is a multiline comment
		  
		   This is a multiline comment
		  
		 */
		
		//Defining variables - Primitive Types
		
		byte b1 = 23;
		
		int num1 = 3;
		int num2 = 4;
		
		long l1 = 234777777777777777L;
		
	
		
		
		System.out.println("b1:"+b1);
		System.out.println("num1:"+num1);
		System.out.println("num2:"+num2);
		
		System.out.println(num1);
		
		char c1 = 'a';
		
		System.out.println("c1:" + c1);
		
		float f1= 23.33f;
		
		double d1 = 234.456;
		
		System.out.println("f1:"+f1);
		System.out.println("d1:"+d1);
		
		boolean bool1 = true;
		boolean bool2 = false;
		
		System.out.println(bool1);
		System.out.println(bool2);
		
		//String type
		
		String s1 = "altug tanaltay";
		String s2 = "belgin tanaltay";
		
		System.out.println(s1);
		System.out.println(s2);
		
		
		
	}
	
	
	
}
