
public class Branching {

	public static void main(String[] args) {
		
		outer:
		for (int i=0 ; i< 101; i++)	{
			System.out.println("i : " + i);
			
			for(int j=0 ; j<50; j++) {
				System.out.println("j : " + j);
				if(j==25) {
					break outer;
				}
				
			}
			
		}
			
		System.out.println("The End.....");
		
	}
	
	

}
