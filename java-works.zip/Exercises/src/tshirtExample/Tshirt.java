package tshirtExample;

public class Tshirt {
	
	private static final int SMALL = 0;
	private static final int MEDIUM = 1;
	private static final int LARGE = 2;
	
	private int size;
	
	public Tshirt(int size) {
		this.size = size;
	}

}
