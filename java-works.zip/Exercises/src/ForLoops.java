
public class ForLoops {
	
	public static void main(String[] args) {
		//i is iterator
		for (int i = 0; i < 101; i++) {
			System.out.println(i);
			
		}
		
		System.out.println("-------------------");
		for (int i = 0; i < 101; i+=2) {
			System.out.println(i);
		}
		
		
		
	}
	

}
