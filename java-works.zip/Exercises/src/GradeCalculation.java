import java.util.Scanner;

public class GradeCalculation {
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Please enter your midterm examination result : ");
			
		int midtermGrade = sc.nextInt();
		
		
		System.out.println("Please enter your process essay result : ");
		
		int essayGrade = sc.nextInt();
		
		System.out.println("Please enter your discussion session result : ");
		
		int discussionGrade = sc.nextInt();
		
		System.out.println("Please enter your in lecture questions result : ");
		
		int lectureGrade = sc.nextInt();
		
		
		double totalResult = midtermGrade * (0.4) + essayGrade * (0.3) + discussionGrade * (0.2) + lectureGrade *(0.1);
		
		
		if (totalResult <= 100 &&  90 <= totalResult ) {
			System.out.println("Your grade letter is A");
		}else if (totalResult<=89 && 86 <= totalResult ){
			System.out.println("Your grade letter is A-");		
		}else if (totalResult<=85 && 82 <= totalResult ) {
			System.out.println("Your grade letter is B+");	
		}else if (totalResult<=81 && 78 <= totalResult ) {
			System.out.println("Your grade letter is B");
		}else if (totalResult<=77 && 74 <= totalResult ) {
			System.out.println("Your grade letter is B-");
		}else if (totalResult<=73 && 70 <= totalResult ) {
			System.out.println("Your grade letter is C+");
		}else if (totalResult<=69 && 66 <= totalResult ) {
			System.out.println("Your grade letter is C");
		}else if (totalResult<=65 && 62 <= totalResult ) {
			System.out.println("Your grade letter is C-");
		}else if (totalResult<=61 && 58 <= totalResult ) {
			System.out.println("Your grade letter is D+");
		}else if (totalResult<=57 && 54 <= totalResult ) {
			System.out.println("Your grade letter is D");
		}else {
			System.out.println("Your grade letter is F");
			
			
		}
		
	}

}
