package HardWork;

public class MainStudent {
	
	public static void main(String[] args) {
		
		System.out.println("Welcome to the registration app.");
		Student s = new Student();
		System.out.println("Student name : " + s.name);
		s.changeName("Isa");
		s.registerCourse("Math-101");
		System.out.println(s.getInfo());
		
	
		
	}

}
