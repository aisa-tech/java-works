package HardWork;

public class Student {

	long id;
	String name;
	String course1;
	
	Student(){
		
		name = "Abdullah Isa YILMAZ";
		
	}

	/*
	Student(String _name){
		name = _name;
	}*/
	
	void changeName(String newName) {
		name = newName;
		
		System.out.println("Student name change to : "+ name);
	}
	void registerCourse(String CourseName) {
		course1 = CourseName;
		System.out.println("The student registered to " + CourseName);
	}
	String getInfo() {
		String output = "";
		output += "Student id : " + id + "\n" ;
		output += "Student name = " + name + "\n";
		output += "Course = " +course1;
		return output ;
		
		
	}
	
	
}
