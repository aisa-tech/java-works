
public class SimpleArrays {
	public static void main(String[] args) {
		
		int[] number = new int[5];
		number[0] = 23;
		number[1] = 12;
		number[2] = 12;
		number[3] = 36;
		number[4] = 42;
		
		System.out.println(number[4]);
		
		System.out.println("Length of numbers : " + number.length);
		
		
		int[] numbers = {5,6,7,8,9};
		 for (int i = 0; i < numbers.length; i++) {
			 System.out.println(numbers[i]);
			
		}
		
		 
		String[] isim = {"Isa,Ali,Aysa"};
		
		for (String name : isim) {
			System.out.println(name);
			
		}
		
		//Default Value
		
		int[] values = new int [3];
		for (int j : values) {
			System.out.println(j);
			
		}
		
	}

}
