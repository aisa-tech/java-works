import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

public class IsaDeneme {
	
	public static void main(String[] args) {
		
		//Arrays
		
		
		String[] myNewString = new String[3];
		myNewString[0] = "James";
		myNewString[1] = "Isa";
		myNewString[2] = "Kirk";
		
		
		int[] myNewInteger = new int[3];
		myNewInteger[0] = 30;
		myNewInteger[1] = 45;
		myNewInteger[2] = 60;
		
		
		System.out.println(myNewInteger[1]);
		
		
		String[] myNew  = {"isa", "ali","ahmet"};
		System.out.println(myNew[1]);
	
		
		//Lists
		
		ArrayList<String>myMusicians = new ArrayList<String>();
		
		myMusicians.add("James");
		myMusicians.add("isa");
		myMusicians.add("lard");
		myMusicians.add("James");
		System.out.println(myMusicians.get(1));
		
		
		HashSet<String>mySet = new HashSet<String>();
		mySet.add("Isa");
		mySet.add("Jesus");
		mySet.add("Isa");
		

		HashMap<String, String>myHashMap= new HashMap<>();
		
		myHashMap.put("book", "alacakaranlik");
		myHashMap.put("takim","Galatasaray" );
		
		System.out.println(myHashMap.get("book"));
		System.out.println(myHashMap.get("takim"));
		

	
	
	}
	
}
