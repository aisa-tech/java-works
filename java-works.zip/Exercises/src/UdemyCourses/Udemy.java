package UdemyCourses;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

public class Udemy {
	
	public static void main(String[] args) {
		
		
		//FOR LOOPS
		
		
		int[] myNumber = {12,15,18,21,24};
		
		for (int i = 0; i < args.length; i++) {
			
			int x = (myNumber[i]/ 3 * 5) ;
			System.out.println(x);
					
		}
		
		int i = 0;
		 
		while(i<10) {
			System.out.println("Isa YILMAZ");
			i++;
		}
		
		
		
	
	//Arrays
	
	
			String[] myNewString = new String[3];
			myNewString[0] = "James";
			myNewString[1] = "Isa";
			myNewString[2] = "Kirk";
			
			
			int[] myNewInteger = new int[3];
			myNewInteger[0] = 30;
			myNewInteger[1] = 45;
			myNewInteger[2] = 60;
			
			
			System.out.println(myNewInteger[1]);
			
			
			String[] myNew  = {"isa", "ali","ahmet"};
			System.out.println(myNew[1]);
	
	
	
			
			
			
			//Lists
			
			ArrayList<String>myMusicians = new ArrayList<String>();
			
			myMusicians.add("James");
			myMusicians.add("isa");
			myMusicians.add("lard");
			myMusicians.add("James");
			System.out.println(myMusicians.get(1));
			
			
			HashSet<String>mySet = new HashSet<String>();
			mySet.add("Isa");
			mySet.add("Jesus");
			mySet.add("Isa");
			

			HashMap<String, String>myHashMap= new HashMap<>();
			
			myHashMap.put("book", "alacakaranlik");
			myHashMap.put("takim","Galatasaray" );
			
			System.out.println(myHashMap.get("book"));
			System.out.println(myHashMap.get("takim"));
			

		
	}

}
