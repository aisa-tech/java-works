package Hafta13;

public class BusMain {
	
	public static void main(String[] args) {
		
		Bus b1= new Bus(Destination.ANKARA);
		Bus b2 = new Bus(Destination.ISTANBUL);
		
		System.out.println(b1.getDestination().name());
		System.out.println(b2.getDestination().name());
		System.out.println(b2.getDestination().ordinal());
		
		
		
	}

}
