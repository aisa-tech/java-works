package Hafta13;

public class Bus {
	
	private Destination destination;
	
	public Bus(Destination destination) {
		
		this.destination = destination;
	}
	public Destination getDestination() {
		return destination;
	}
		
	

}
