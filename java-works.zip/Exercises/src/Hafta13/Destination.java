package Hafta13;


	public enum Destination {
		ANKARA,ISTANBUL

}
