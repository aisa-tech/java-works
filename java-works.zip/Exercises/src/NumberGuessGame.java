import java.util.Random;
import java.util.Scanner;

public class NumberGuessGame {
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		Random rnd = new Random();
		int randNum = rnd.nextInt(10);
		
		System.out.println(randNum);
		
		
		System.out.println("Please enter a number : ");
		
		int count = 0;
		while (count<11){
			
			System.out.println("Count- " + (count+1));
			int guess  = sc.nextInt();
			
			if(guess<randNum) {
				System.out.println("Please guess higher");
			}else if(guess>randNum) {
				System.out.println("Please guess lower");
			
			}else {
				System.out.println("you got it :))))))");
				break;
			}
		}
		
	}

}
