package flightExercise;

import java.time.LocalDateTime;

public class Flight {
	private long id;
	private String destination;
	private String departure;
	private LocalDateTime departureTime;
	private LocalDateTime arrivalTime;
	private Pilot[] pilot;
	private Plane plane;
	private boolean cancelled;
	
	
	
	
	public Flight() {
		// TODO Auto-generated constructor stub
	}




	public Flight(long id, String destination, String departure, LocalDateTime departureTime, LocalDateTime arrivalTime,
			Pilot[] pilot, Plane plane, boolean cancelled) {
		super();
		this.id = id;
		this.destination = destination;
		this.departure = departure;
		this.departureTime = departureTime;
		this.arrivalTime = arrivalTime;
		this.pilot = pilot;
		this.plane = plane;
		this.cancelled = cancelled;
	}


	public String displayInformation() {
		String information = "ID  :" + id + "\nDestination :  " + destination + "\nDeparture : " + departure + "\nDeparture time : "+ departureTime + "\nArrival Time : " + arrivalTime + "\nPlane : "+ plane.getName();
		information += "\n PILOTS : ";
		for (Pilot pilots : pilot) {
			information += pilots.displayInformation();
			
		}
		return information;
			
		}
		
	


	public void reassignPilot (Pilot newPilot) {
		System.out.println("New Pilot Assigned");
		if(pilot != null ) {
			for (int i = 0; i < pilot.length; i++) {
				if(pilot[i].getStatus() == newPilot.getStatus()) {
					pilot[i] = newPilot;
					break;
				}
				
			}
		}
	}
	
	
	public void cancelFlight() {
		if (cancelled == true ) {
			System.out.println("Flight is cancelled...");
		}else {
			System.out.println("Floight is NOT cancelled...");
		}
	}
	
	

	public long getId() {
		return id;
	}




	public void setId(long id) {
		this.id = id;
	}




	public String getDestination() {
		return destination;
	}




	public void setDestination(String destination) {
		this.destination = destination;
	}




	public String getDeparture() {
		return departure;
	}




	public void setDeparture(String departure) {
		this.departure = departure;
	}




	public LocalDateTime getDepartureTime() {
		return departureTime;
	}




	public void setDepartureTime(LocalDateTime departureTime) {
		this.departureTime = departureTime;
	}




	public LocalDateTime getArrivalTime() {
		return arrivalTime;
	}




	public void setArrivalTime(LocalDateTime arrivalTime) {
		this.arrivalTime = arrivalTime;
	}




	public Pilot[] getPilot() {
		return pilot;
	}




	public void setPilot(Pilot[] pilot) {
		this.pilot = pilot;
	}




	public Plane getPlane() {
		return plane;
	}




	public void setPlane(Plane plane) {
		this.plane = plane;
	}




	public boolean isCancelled() {
		return cancelled;
	}




	public void setCancelled(boolean cancelled) {
		this.cancelled = cancelled;
	}
	
	
	
	
	

}
