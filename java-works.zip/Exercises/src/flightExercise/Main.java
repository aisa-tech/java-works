package flightExercise;

import java.time.LocalDateTime;

public class Main {
	
	public static void main(String[] args) {
		
		Plane plane = new Plane(4567L, "Pegasus", 99, 4300, "LArge jet");
		
		LocalDateTime birthDate = LocalDateTime.of(1995, 7, 28, 13, 30);
		LocalDateTime jobStartDate = LocalDateTime.of(2018, 6, 8, 8, 00);
		
		Pilot pilot1 = new Pilot(2090, "Isa YILMAZ", birthDate, jobStartDate, "Secondary");
		Pilot pilot2 = new Pilot(2001, "Kerim Ozkan", birthDate, jobStartDate, "Primary");
		
		Pilot[] pilot = new Pilot[] {pilot1,pilot2};
		
		LocalDateTime departureTime = LocalDateTime.of(2020, 7, 28, 12, 00);
		LocalDateTime arrivalTime = LocalDateTime.of(2020, 7, 28, 15, 00);
		
		Flight flight = new Flight(1881, "Krakow", "Istanbul", departureTime, arrivalTime, pilot, plane, true);
		
		System.out.println(flight.displayInformation());
		Pilot newPilot = new Pilot(2000, "Orhun Bozkulak", birthDate, jobStartDate, "Primary");
		
		flight.reassignPilot(newPilot);
		flight.cancelFlight();
		
	}
	
	
	

}
