import java.util.Scanner;

public class WhileDoWhile {
			
	public static void main(String[] args) {
		
		/*
		 * int count = 0;
		 * 
		 * while (count<101) { System.out.println(count); count++ ; }
		 */
		
		/*
		 * Scanner sc = new Scanner(System.in);
		 * 
		 * char A = 'A'; System.out.println((int)A);
		 * 
		 * char B = 'B'; System.out.println((int)B);
		 * 
		 * char a = 'a'; System.out.println((int)a);
		 */
		Scanner sc = new Scanner(System.in);
		char input = '9';
				
		do {
			System.out.println("Please enter a character : ");
			input = sc.next().charAt(0);
			
		}while(!(input>='A' && input<='z'));
		
		System.out.println("Well done :)");
	
	}
}
