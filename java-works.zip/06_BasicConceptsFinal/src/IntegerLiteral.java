
public class IntegerLiteral {

	
	public static void main(String[] args) {
		
		
		//Every number literal int sized or smaller in Java are ints 
		
		byte b1 =  67;
		byte b2 = 45;
		
		byte byteSum = (byte)(b1+b2);
		
		short s1 = 345;
		short s2 = 34;
		short sSum = (short)(s1+s2);
		
		
		long lll = 233333333333333333l;
		
	}
	
	
	
	
}
