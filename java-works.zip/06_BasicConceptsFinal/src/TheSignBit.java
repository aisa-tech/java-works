
public class TheSignBit {

	
	public static void main(String[] args) {
		
		
		byte b = (byte)128;
		
		System.out.println(b);
		
		
	}
	
	
}
