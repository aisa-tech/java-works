
public class TypeCasting {

	
	public static void main(String[] args) {
		
		
		int x1 = 23;
		long s = x1;
		
		int x2 = 45;
		
		//PRIMITIVE TYPE CASTING
		
		//implicit type casting
		long sumLong = x1+x2;
		
		//implicit type casting
		double sumDouble = x1+x2;
		
		System.out.println(sumDouble);
		
		double d1 = 23.3;
		double d2= 32.2;
		
		//The following code creates a compiler error
		//explicit cast is required
		//int sumInt = d1+d2;
		
		//Explicit primitive type casting
		
		int sumInt = (int)(d1+d2);
		System.out.println(sumInt);
		System.out.println("------");
		
		int num = 5;
		System.out.println((4.0/num));
		
		
		//NON PRIMITIVE CASTING
		
		String strNum = "23";
		//Use wrapper types for non primitive casting
		//Double, Integer, Double, Long, Boolean..
		int intNum = Integer.valueOf(strNum);
		
		int someNumber = 345;
		
		String strSomeNumber = String.valueOf(someNumber);
		
		
		
	}
	
	
	
}
