package com.main;

public class Circle {

	private String color;
	private double radius;
	
	public Circle() {
		// TODO Auto-generated constructor stub
	}
	
	
	public Circle(String color, double radius) {
		this.color = color;
		this.radius = radius;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public double getRadius() {
		return radius;
	}
	public void setRadius(double radius) {
		this.radius = radius;
	}
	
	
	
}
