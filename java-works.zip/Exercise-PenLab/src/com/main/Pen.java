package com.main; 
public class Pen {
//Overloaded draw methods
	public void drawShape(Rectangle r){
		

		System.out.println("Color is " 
				+ r.getColor()
				+ " width is " +r.getWidth() 
				+ " height is " + r.getHeight());

	}
	public void drawShape(Circle c){

		System.out.println("Color is " 
				+ c.getColor()
				+ " radius is " + c.getRadius());
		

	}
	//Overloaded changeColor methods
	public void changeColor(String color, Rectangle r){
		r.setColor(color);
		System.out.println("Rectangle color changed to  " + r.getColor());
		
	}
	public void changeColor(String color, Circle c){
		c.setColor(color);
		System.out.println("Circle color changed to  " + c.getColor());
	}
	
}
