import java.util.Scanner;

public class DNASeq2 {

	public static void main(String[] args) {

		char[] validChars = { 'A', 'C', 'G', 'T' };
		Scanner sc = new Scanner(System.in);

		boolean seqValid = false;

		outer:
		while(!seqValid) {
			System.out.println("Please enter a valid sequence?");
			String data = sc.nextLine();
			char[] input = data.toCharArray();

			
			for (char c : input) {
				
				boolean charValid = false;
				for(char v:validChars) {
					if(c==v) {
						charValid=true;
						break;
					}
				}
				
				if(!charValid) {
					continue outer;	
				}
	
			}
			
			seqValid = true;
		}
		
		System.out.println("Sequence valid");

	}

}
