import java.util.Scanner;

public class DNASeq {

	public static void main(String[] args) {

		char[] validChars = { 'A', 'C', 'G', 'T' };
		Scanner sc = new Scanner(System.in);

		boolean seqValid = true;
		do {
			seqValid = true;
			System.out.println("Please enter a valid sequence?");
			String data = sc.nextLine();
			char[] input = data.toCharArray();

			for (char c : input) {

				if (!(c == 'A' || c == 'C' || c == 'G' || c == 'T')) {
					seqValid = false;
				}
			}
		} while (!seqValid);
		System.out.println("Seq is valid");
	}

}
