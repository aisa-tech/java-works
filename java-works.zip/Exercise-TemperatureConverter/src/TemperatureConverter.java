
public class TemperatureConverter {

	private String toType;
	
	public TemperatureConverter(String toType) {
		this.toType = toType;
	}
	
	public double convert(double value) {
		
		if(toType.equals("f")) {
			return (value-32)*(5.0/9.0);
		}else {
			return value*(9.0/5.0) + 32;
		}
		

		
	}
	
	public static void main(String[] args) {
		double value = Double.valueOf(args[0]);
		String type = args[1];
		
		TemperatureConverter converter = new TemperatureConverter(type);
		double result = converter.convert(value);
		
		if(converter.toType.equals("f")) {
			System.out.println(value + " degrees to fahreneit is "  + result);
		}else {
			System.out.println(value + " degrees to celcius is "  + result);
		}
		
		
	}
	
	
}
