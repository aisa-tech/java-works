package main;

public class Person{
	private String name;
	
	public void setName(String name) {
		this.name = name;
	}
	public String getName() {
		return name;
	}
	
	// A good Java programmer always overrides toString() and equals() methods
	
	@Override
	public boolean equals(Object obj) {
		
		if(obj instanceof Person) {
			return ((Person)obj).getName().equals(name);
		}
		
		return false;
		
	}
	
	@Override
	public String toString() {
		return "Person, name:" + name;
	}
	
	
}
