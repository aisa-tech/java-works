package main;

public class MainClass {

	
	public static void main(String[] args) {
		
		
		Person p1 = new Person();
		p1.setName("Altug");
		
		
		Person p2 = new Person();
		p2.setName("Altug");
		
		
		//== operator checks if the references point to the same object in the memory
		if(p1==p2) {
			System.out.println("Equal");
		}else System.out.println("Not equal");
		
		
		
		Person p3 = p1;
		
		if(p1==p3) {
			System.out.println("Equal");
		}else System.out.println("Not equal");
		
		System.out.println("------------");
		
		// The equals() method in Object type doeas the same operation with ==
		// if NOT OVERRIDDEN
		if(p1.equals(p2)) {
			System.out.println("Equal");
		}else System.out.println("Not equal");
		
		if(p1.equals(p3)) {
			System.out.println("Equal");
		}else System.out.println("Not equal");
		
		System.out.println("-----------");
		
		System.out.println(p1);
		
		
	}
	
	
	
}
