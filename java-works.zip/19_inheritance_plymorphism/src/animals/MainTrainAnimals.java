package animals;

public class MainTrainAnimals {

	
	public static void main(String[] args) {
		
		ZooKeeper keeper = new ZooKeeper();
		
		HouseCat felix = new HouseCat();
		
		Leopard lenny = new Leopard();
		
		Dog fluffy = new Dog();
		
		
		keeper.trainAnimal(felix);
		keeper.trainAnimal(lenny);
		
		keeper.trainAnimal(fluffy);
		
		
	}
	
	
	
}
