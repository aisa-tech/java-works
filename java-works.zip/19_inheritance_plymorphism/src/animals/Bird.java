package animals;

public class Bird extends Animal{

	private String climate;
	
	
	public String getClimate() {
		return climate;
	}
	
	public void setClimate(String climate) {
		this.climate = climate;
	}
	
}
