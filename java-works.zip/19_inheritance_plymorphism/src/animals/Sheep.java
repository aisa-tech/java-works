package animals;

public class Sheep extends Animal{

	@Override
	public void makeSound() {
		System.out.println("mee mee mee");
	}
	@Override
	public void getFed() {
		System.out.println("Sheep got fed");
	}
	
	
}
