package animals;

public class Cat extends Animal{
	
	private String origin;
	
	
	
	public Cat() {
		// TODO Auto-generated constructor stub
	}
	
	
	
	
	public Cat(String color, int numOfLegs, String origin) {
		super(color, numOfLegs);
		this.origin = origin;
	}

	
	public void getTrained() {
		System.out.println("Cat cannot be trained");
	}
	
	public String getOrigin() {
		return origin;
	}
	
	public void setOrigin(String origin) {
		this.origin = origin;
	}
}
