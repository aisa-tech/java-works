package animals;

public class MainWithOverriddenMethods {

	
	public static void main(String[] args) {
		
		//Compile time = Runtime
		HouseCat houseCat = new HouseCat();
		
		Animal dog1 = new Dog();
		
		Bird parrot1 = new Parrot();
		
		Animal sheep = new Sheep();
		
		
		//Below, always the overridden methods will be invoked
		houseCat.makeSound();
		
		dog1.makeSound();
		
		parrot1.makeSound();
		
		sheep.makeSound();
		
		

		
		
		
	}
	
	
	
	
}
