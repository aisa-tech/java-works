package animals;

public class HouseCat extends Cat{

	private String owner;

	public HouseCat() {
		// TODO Auto-generated constructor stub
	}
	
	
	public HouseCat(String color, int numOfLegs, String origin, String owner) {
		super(color, numOfLegs, origin);
		this.owner = owner;
	}
	
	@Override
	public void getTrained() {
		System.out.println("House cat got trained");
	}
	
	
	@Override
	public void getFed() {
		System.out.println("House cat got fed");
	}
	
	@Override
	public void makeSound() {
		System.out.println("Miyaeowww");
	}

	public String getOwner() {
		return owner;
	}
	
	public void setOwner(String owner) {
		this.owner = owner;
	}
	
}
