package animals;

public class Leopard extends Cat{

	
	
	
	@Override
	public void getTrained() {
		System.out.println("Leopard cat got trained");
	}
	
	
	//Annotation
	//in order to override we don't need the annotiaton below
	
	@Override
	public void getFed() {
		System.out.println("Leopard got fed");
	}
	
	@Override
	public void makeSound() {
		System.out.println("kioaweree");
		
	}
	
	
	
}
