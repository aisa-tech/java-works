package animals;

public class Parrot extends Bird{

	private String country;
	
	@Override
	public void getFed() {
		System.out.println("Parrot got fed");
	}
	
	@Override
	public void makeSound() {
		System.out.println("parrot sound");
	}
	
	public String getCountry() {
		return country;
	}
	
	public void setCountry(String country) {
		this.country = country;
	}
}
