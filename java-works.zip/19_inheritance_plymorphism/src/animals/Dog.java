package animals;

public class Dog extends Animal{

	
	@Override
	public void makeSound() {
		System.out.println("Woff woff");
	}
	
	
	public void catchHunt() {
		System.out.println("Dog is catching the hunt..");
	}
	
	
	@Override
	public void getFed() {
		System.out.println("Dog got fed");
	}
	
}
