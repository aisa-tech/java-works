package animals;

import java.util.ArrayList;

public class FeedingAnimalsMain {

	
	
	public static void main(String[] args) {
		
		
		Dog dog1 = new Dog();
		
		Animal cat1 = new HouseCat();
		
		Chicken chick = new Chicken();
		
		
		ZooKeeper zooKeeper = new ZooKeeper();
		
		zooKeeper.feed(dog1);
		zooKeeper.feed(cat1);
		zooKeeper.feed(chick);
		
		System.out.println("---------------");
		
		Animal[] animals = new Animal[] {dog1,cat1,chick};
		
		zooKeeper.feedAnimals(animals);
		
		System.out.println("-----------");
		ArrayList<Animal> animalsList = new ArrayList<Animal>();
		
		animalsList.add(dog1);
		animalsList.add(cat1);
		animalsList.add(chick);
		
		for (Animal animal : animalsList) {
			animal.makeSound();
		}
		
		System.out.println("-----------");
		
		zooKeeper.feedAnimals(animalsList);
		
		
		
		//The code below creates a compiler error
		//methods feedAnimals() only accept ArrayList<Animal>
		//ArrayList<Dog> dogList = new ArrayList<Dog>();
		//dogList.add(new Dog());
		//dogList.add(new Dog());
		
		//zooKeeper.feedAnimals(dogList);
		
	}
	
	
	
}
