package animals;

public class MainAnimals {

	public static void main(String[] args) {
		
		/*
		HouseCat cat = new HouseCat("Black", 4, "Anatolia", "Altug");
		
		System.out.println(cat.getColor());
		System.out.println(cat.getOwner());
		
		
		Animal a = new Animal();
		a.makeSound();
		
		cat.makeSound();
		*/
		
		//Polymorphic declarations
		
		
		Animal dog = new Dog();
		
		dog.getColor();
		
		//The code below creates a compiler error as 
		// Animal reference cannot access Dog fields or methods.
		//dog.catchHunt();
		
		
		//Animal reference cannot access dog fileds or methods
		
		Animal cat2 = new HouseCat();
		
		Cat leopard = new Leopard();
		
		Bird parrot1 = new Parrot();
		
		
		
		
		
		//Below create compiler errors as
		// Anima is not a Dog
		//Cat is not a HouseCat
		//Dog dog3 = new Animal();
		//HouseCat felix = new Cat();
		
		
	
		
		
		
	}
	
	
	
}
