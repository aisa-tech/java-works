package animals;

public class Lion extends Cat{

	
	@Override
	public void getTrained() {
		System.out.println("Lion cat got trained");
	}
	
	
	@Override
	public void makeSound() {

		System.out.println("Roarrrr!!");
		
		
	}
	@Override
	public void getFed() {
		System.out.println("Lion got fed");
	}
	
	
}
