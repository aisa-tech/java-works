package animals;

import java.util.ArrayList;

public class ZooKeeper {

	
	/* The methods below are bad designs
	public void feed(HouseCat cat) {
		System.out.println("Cat with owner " + cat.getOwner() +  " got fed..");
	}
	
	public void feed(Parrot parrot) {
		System.out.println("Parrot with country " + parrot.getCountry() +  " got fed..");
	}
	
	*/
	
	public void trainAnimal(Animal animal) {
		
		//Downcasting
		//Cat cat = (Cat)animal;
		//cat.getTrained();
		if(animal instanceof Cat) {
			((Cat)animal).getTrained();
		}else System.out.println(animal.getClass().getName() +  " cannot be trained");
		
		
	}
	
	
	
	
	// feed methods accepts Animal and all subtypes
	public void feed(Animal animal) {
		animal.getFed();
	}
	
	public void feedAnimals(Animal[] animals) {
		for (Animal animal : animals) {
			animal.getFed();
		}
	}
	
	public void feedAnimals(ArrayList<Animal> animals) {
		for (Animal animal : animals) {
			animal.getFed();
		}
	}
	
}
