package animals;

public class Chicken extends Bird {

	@Override
	public void makeSound() {
		System.out.println("gidak gidak..");
	}
	
	@Override
	public void getFed() {
		System.out.println("Chicken got fed");
	}
}
