package example1;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;

public class TextFileWriteExample {
	
	public static void main(String[] args) {
		
		BufferedWriter writer =null;
		
		try {
			
			
			String output = "Isa YILMAZ\nKerim OZKAN\nEnes KACAR\nBunyamin YASAR\nAhmet KASAR";
			writer = new BufferedWriter(new FileWriter(new File("names.ddc")));
			writer.write(output);
			writer.flush();
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				writer.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
			
		
		
		
		
		
		
		
		
	}
	

		
	

}
