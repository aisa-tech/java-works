package example1;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class TextFileReadExample {
	public static void main(String[] args) {
		
		BufferedReader reader =null;
		try {
			reader = new BufferedReader(new FileReader(new File("names.ddc")));
			String line ="";
			while((line = reader.readLine())!=null) {
				System.out.println(line);
			}
				
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.out.println("File doesnt exist");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				reader.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		
		
		
		
	}

}
