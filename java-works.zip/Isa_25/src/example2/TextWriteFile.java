package example2;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class TextWriteFile {
	
	public static void main(String[] args) {
		
		BufferedWriter writer = null;
		
		try {
			String output = "Math\nIT\nNatural Science\nGeograpy\nPython";
			writer = new BufferedWriter(new FileWriter(new File("exam.ddt"),true));
			writer.write(output);
			writer.flush();
			
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				writer.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		
		
	}

}
