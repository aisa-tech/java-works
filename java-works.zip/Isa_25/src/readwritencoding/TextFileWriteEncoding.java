package readwritencoding;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;

public class TextFileWriteEncoding {

	
	public static void main(String[] args) {
		//Plus Encoding
		//Encoding supper reader and writer types: InputStreamReader and OutputStreamWriter
		
		try(	BufferedWriter writer = new BufferedWriter
					(new OutputStreamWriter(new FileOutputStream("encoding.ddt"), "utf-8"));) {
			
			
			String output = "ÇÇŞŞĞĞüüiiİİİİ\nMore and ÇÇööÖÖççÇÇşşİİİİğğüüüÜÜÜ\nmore more more content";
			writer.write(output);
			writer.flush();
		
	
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		
		
		
		
	}
}
