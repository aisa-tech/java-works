package readwritencoding;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;

public class TextFileReadingEncoding {
	public static void main(String[] args) {
		
		StringBuilder buffer = new StringBuilder();
		
		try (	BufferedReader reader =new BufferedReader
					(new InputStreamReader(new FileInputStream("encoding.ddt"),"utf-8"));){
			
		String line = "";
		while((line = reader.readLine())!=null) {
			buffer.append(line+ "\n");
		}
			
			System.out.println(buffer);
			
			
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		
		
		
	}

}
