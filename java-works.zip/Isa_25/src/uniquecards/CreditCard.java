package uniquecards;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class CreditCard {
	
	public static void main(String[] args) {
		
		ArrayList<String>unique = new ArrayList<>();
		ArrayList<String>multiple = new ArrayList<>();
		try(BufferedReader reader = new BufferedReader
				(new FileReader("creditcards.ddt"));) {
			
			String line="";
			while((line=reader.readLine())!=null) {
				if(unique.contains(line)) {
					if(!multiple.contains(line)) {
						multiple.add(line);
					}
				}else {
					unique.add(line);
				}
				
			}

			System.out.println("Unique cards :" + unique.size());
			System.out.println("Multiple cards : "+multiple.size());
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		

		
	}

}
