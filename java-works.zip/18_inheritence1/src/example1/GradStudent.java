package example1;

public class GradStudent extends Student{
	
	private String thesisSubject;
	
	public GradStudent() {
		// TODO Auto-generated constructor stub
	}
	
	public GradStudent(int id, String name, String lastname, String department, String registeredCourses,
			String thesisSubject) {
		super(id, name, lastname, department, registeredCourses);
		this.thesisSubject = thesisSubject;
	}

	/*
	public GradStudent() {
		//super class constructor called
		//super keyword is used to access the super class
		//super() -> super class's constructor call
		//this() -> calls a constructor of the current class
		super();

		System.out.println("Grad stu constructor");
	}
	*/
	public String getThesisSubject() {
		return thesisSubject;
	}
	
	public void setThesisSubject(String thesisSubject) {
		this.thesisSubject = thesisSubject;
	}

}
