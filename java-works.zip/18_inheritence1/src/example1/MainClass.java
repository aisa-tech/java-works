package example1;

public class MainClass {

	public static void main(String[] args) {
		
		/*
		GradStudent grdStu1 = new GradStudent();
		grdStu1.setDepartment("HISTORY");
		grdStu1.setName("altug");
		grdStu1.setId(1);
		grdStu1.setRegisteredCourses("MATH, HIST, SOC");
		grdStu1.setThesisSubject("World History");

		
		System.out.println(grdStu1.getName());
		System.out.println(grdStu1.getRegisteredCourses());
		System.out.println(grdStu1.getThesisSubject());
		*/
		
		
		//Constructor chaining
		//A subclass construct first calls super class cnstructor
		GradStudent grdStu = new GradStudent(1,"altug","tanaltay","IT","MATH, HIST","IT");
		System.out.println(grdStu.getLastname());
		
		
		
		
	}
	
	
	
	
}
