package example1;

public class Teacher extends Person{
	
	private String coursesOffered;
	
	
	/*
	public Teacher() {
		System.out.println("Teacher constructor");
	}
	*/
	
	public Teacher(int id, String name, String lastname, String department, String coursesOffered) {
		super(id, name, lastname, department);
		this.coursesOffered = coursesOffered;
	}

	public void teachACourse() {
		System.out.println("A course is tought");
	}
	
	public String getCoursesOffered() {
		return coursesOffered;
	}
	
	public void setCoursesOffered(String coursesOffered) {
		this.coursesOffered = coursesOffered;
	}

}
