package example1;

public class Student extends Person{
	
	private String registeredCourses;
	
	
	public Student(int id, String name, String lastname, 
			String department, String registeredCourses) {
		super(id, name, lastname, department);
		this.registeredCourses = registeredCourses;
	}

	
	public Student() {
		//super class constructor called
		super();
		
		System.out.println("Student constructor");
	}
	
	
	
	
	public void study(String coursename) {
		System.out.println("The student studies " + coursename);
	}

	public String getRegisteredCourses() {
		return registeredCourses;
	}
	
	public void setRegisteredCourses(String registeredCourses) {
		this.registeredCourses = registeredCourses;
	}
	
}
