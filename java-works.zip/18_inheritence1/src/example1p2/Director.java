package example1p2;

import example1.Person;

public class Director extends Person{

	public Director(int id, String name, String lastname, String department) {
		super(id, name, lastname, department);
		// TODO Auto-generated constructor stub
	}

	
	
	
	
	public Director() {
		
		//aVariable has default access in Person class,
		//so it is not acceassble in Director class
		//aVariable = "some value";
		
		
		
	}
	
	
	
	
}
