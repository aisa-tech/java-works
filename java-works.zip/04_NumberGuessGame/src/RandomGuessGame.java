

import java.util.Random;
import java.util.Scanner;

public class RandomGuessGame {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		Random rnd = new Random();
		int number = rnd.nextInt(100);
		
		System.out.println(number);
		
		System.out.println("I have a number in my mind, can you guess it?");

		boolean found = false;
		int steps = 0;
		
		while(steps<10) {
			System.out.println("Step-" + (steps+1));
			int guess = sc.nextInt();
			
			if(guess<number) {
				System.out.println("Higher");
			}else if(guess>number) {
				System.out.println("Lower");
			}else {
				found = true;
				break;
			}
			
			steps++;
			
		}
		if(found) {
			System.out.println("You nailed it in " + steps + " steps.");
		}else {
			System.out.println("May be next time");
		}
		
		
		
		
		
	}
	
	
	
	
	
}
