package model;

import java.time.LocalDateTime;

public class Order {

	private int id;
	private LocalDateTime orderDate;
	private OrderItem[] orderItems;
	
	
	public Order(int id, LocalDateTime orderDate, OrderItem[] orderItems) {
		this.id = id;
		this.orderDate = orderDate;
		this.orderItems = orderItems;
	}

	
	public String getInfo() {
		
		String retVal = "Order - " + id + "\n";
		retVal+= "Date:" + orderDate.toString() + "\n";
		
		for (OrderItem orderItem : orderItems) {
			retVal+= orderItem.getInfo();
		}
		
		retVal+= "Order Total amount:" + getTotalAmount() + "\n";
		
		return retVal;
	}
	
	public double getTotalAmount() {
		
		double sum = 0;
		for (OrderItem orderItem : orderItems) {
			sum+=orderItem.getTotalValue();
		}
		
		return sum;
		
	}

	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public LocalDateTime getOrderDate() {
		return orderDate;
	}


	public void setOrderDate(LocalDateTime orderDate) {
		this.orderDate = orderDate;
	}


	public OrderItem[] getOrderItems() {
		return orderItems;
	}


	public void setOrderItems(OrderItem[] orderItems) {
		this.orderItems = orderItems;
	}
	
	
	
	
	
}
