package model;

import java.util.ArrayList;

public class Customer {
	
	private int id;
	private String name;
	private ArrayList<Order> orders;
	
	//For preventing null pointer exception on orders ArrayList
	//we need to initialize it in the default constructor.
	public Customer() {
		orders = new ArrayList<Order>();
	}


	public Customer(int id, String name, ArrayList<Order> orders) {

		this.id = id;
		this.name = name;
		this.orders = orders;
	}

	public String getInfo() {
		
		String retVal = "Customer, id:" + id + ", name:" + name + "\n";
		
		for (Order order : orders) {
			retVal+= order.getInfo();
		}
		retVal += "Customer total orders:" + getCustomerTotalExpenditure();
		return retVal;
		
	}
	
	public double getCustomerTotalExpenditure() {
		double sum = 0;
		for (Order order : orders) {
			sum+= order.getTotalAmount();
		}
		
		return sum;
	}
	

	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public ArrayList<Order> getOrders() {
		return orders;
	}


	public void setOrders(ArrayList<Order> orders) {
		this.orders = orders;
	}
	
	
	

}
