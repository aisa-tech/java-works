package model;

public class OrderItem {

	private Product product;
	private int amount;
	
	
	
	public OrderItem() {
		// TODO Auto-generated constructor stub
	}



	public OrderItem(Product product, int amount) {
		this.product = product;
		this.amount = amount;
	}

	public String getInfo() {
		
		String retVal = "Item:\n";

		retVal+="Product:" + product.getName() + ", amount:" + amount + ", tax:" + product.getTax() + "\n";
		retVal+= "Total amount:" + getTotalValue() + "\n";
		
		
		return retVal;
		
	}
	
	public double getTotalNetValue() {
		double netValue = product.getPrice() * amount;
		return netValue;
	}
	
	public double getTotalTaxValue() {
		return getTotalNetValue()*product.getTax();
	}

	
	public double getTotalValue() {
		return getTotalNetValue() + getTotalTaxValue();
	}

	public Product getProduct() {
		return product;
	}



	public void setProduct(Product product) {
		this.product = product;
	}



	public int getAmount() {
		return amount;
	}



	public void setAmount(int amount) {
		this.amount = amount;
	}
	
	
	
	
}
