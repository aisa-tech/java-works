package main;

import java.time.LocalDateTime;
import java.util.ArrayList;

import model.Customer;
import model.Order;
import model.OrderItem;
import model.Product;

public class MainCLass {

	public static void main(String[] args) {
		
		Product laptop = new Product("Laptop", 2500, 0.18);
		Product charger = new Product("Charger", 34.0, 0.18);
		Product mouse = new Product("Mouse", 240, 0.18);
		
		
		//Customer X's orders:
		
		
		//First Order:
		OrderItem item1 = new OrderItem(laptop, 1);
		OrderItem item2 = new OrderItem(mouse,2);
		
		OrderItem[] items1 = new OrderItem[] {item1, item2};
		
		//LocalDateTime
		
		LocalDateTime order1Date =  LocalDateTime.now();
		
		Order order1 = new Order(1, order1Date, items1);
		
		//Second Order:
		OrderItem item3 = new OrderItem(charger, 4);
		OrderItem item4 = new OrderItem(mouse,1);
		
		OrderItem[] items2 = new OrderItem[] {item3, item4};
		
		//LocalDateTime
		
		LocalDateTime order2Date =  LocalDateTime.of(2020, 12, 12, 12, 0);
		
		Order order2 = new Order(2, order2Date, items2);
		
		
		//Customer:
		
		ArrayList<Order> customer1Orders = new ArrayList<Order>();
		customer1Orders.add(order1);
		customer1Orders.add(order2);
		
		Customer customer1 = new Customer(1, "Altug Tanaltay", customer1Orders);
		
		System.out.println(customer1.getInfo());
		
		
		
		
		
		
		
	}
	
	
	
}
