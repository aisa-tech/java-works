package model;

import java.time.LocalDateTime;
import java.util.ArrayList;

public class Wedding extends Event{

	private Person groom;
	private Person bride;
	
	
	
	
	public Wedding(String name, LocalDateTime start, LocalDateTime finish, String place, ArrayList<Person> attendees,
			Person groom, Person bride) {
		super(name, start, finish, place, attendees);
		this.groom = groom;
		this.bride = bride;
	}




	@Override
	public void printSummary() {
		System.out.println("Wedding:");
		System.out.println("Groom:" + groom);
		System.out.println("Bride:" + bride);
		System.out.println(super.toString());
		System.out.println("---------");
		
	}




	public Person getGroom() {
		return groom;
	}




	public void setGroom(Person groom) {
		this.groom = groom;
	}




	public Person getBride() {
		return bride;
	}




	public void setBride(Person bride) {
		this.bride = bride;
	}
	
	
	
	
	
	
}
