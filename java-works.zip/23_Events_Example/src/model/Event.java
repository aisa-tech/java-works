package model;

import java.time.LocalDateTime;
import java.util.ArrayList;

public abstract class Event {
	

	private String name;
	private LocalDateTime start;
	private LocalDateTime finish;
	private String place;
	private ArrayList<Person> attendees;
	/*
	public Event() {
		// TODO Auto-generated constructor stub
		attendees = new ArrayList<Person>();
	}
	*/

	public Event(String name, LocalDateTime start, LocalDateTime finish, String place, ArrayList<Person> attendees) {
		super();
		this.name = name;
		this.start = start;
		this.finish = finish;
		this.place = place;
		this.attendees = attendees;
	}

	
	
	public abstract void printSummary();
	
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Event other = (Event) obj;
		if (finish == null) {
			if (other.finish != null)
				return false;
		} else if (!finish.equals(other.finish))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (place == null) {
			if (other.place != null)
				return false;
		} else if (!place.equals(other.place))
			return false;
		if (start == null) {
			if (other.start != null)
				return false;
		} else if (!start.equals(other.start))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Event [name=" + name + ", start=" + start + ", finish=" + finish + ", place=" + place + ", attendees="
				+ attendees + "]";
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public LocalDateTime getStart() {
		return start;
	}

	public void setStart(LocalDateTime start) {
		this.start = start;
	}

	public LocalDateTime getFinish() {
		return finish;
	}

	public void setFinish(LocalDateTime finish) {
		this.finish = finish;
	}

	public String getPlace() {
		return place;
	}

	public void setPlace(String place) {
		this.place = place;
	}

	public ArrayList<Person> getAttendees() {
		return attendees;
	}

	public void setAttendees(ArrayList<Person> attendees) {
		this.attendees = attendees;
	}
	
	
	

}
