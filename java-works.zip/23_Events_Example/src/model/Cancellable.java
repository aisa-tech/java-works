package model;

public interface Cancellable {

	public void cancel();
	
}
