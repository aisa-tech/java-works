package model;

import java.time.LocalDateTime;
import java.util.ArrayList;

public class Meeting extends Event implements Cancellable{

	private String subject;
	
	
	
	
	public Meeting(String name, LocalDateTime start, LocalDateTime finish, String place, ArrayList<Person> attendees,
			String subject) {
		super(name, start, finish, place, attendees);
		this.subject = subject;
	}

	@Override
	public void cancel() {
		System.out.println("Meetng is canceled, room is cleared.");
		for (Person attendee : getAttendees()) {
			System.out.println(attendee + " is mailed...");
		}
		
		
	}

	@Override
	public void printSummary() {
		System.out.println("Meeting:");
		System.out.println("Subject:" + subject);
		System.out.println(super.toString());
		System.out.println("---------");
		
	}
	public String getSubject() {
		return subject;
	}
	
	public void setSubject(String subject) {
		this.subject = subject;
	}
}
