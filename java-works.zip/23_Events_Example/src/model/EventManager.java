package model;

import java.util.ArrayList;

public class EventManager {

	private ArrayList<Event> events = new ArrayList<Event>();
	
	
	public void scheduleEvent(Event evt) {
		events.add(evt);
		System.out.println("Event scheduled:");
		evt.printSummary();
	}
	

	public void cancelEvent(Cancellable cancellable) {
		System.out.println("Cancel Event:");
		
		cancellable.cancel();
		
		if(cancellable instanceof Event) {
			((Event)cancellable).printSummary();
			events.remove((Event)cancellable);
		}
		
		
	}
	
	public void listEvents() {
		System.out.println("Scheduled Events:");
		for (Event event : events) {
			event.printSummary();
		}
		System.out.println("-----------");
	}
	
	
	
}
