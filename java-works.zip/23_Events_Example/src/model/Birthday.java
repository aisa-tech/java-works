package model;

import java.time.LocalDateTime;
import java.util.ArrayList;

public class Birthday extends Event implements Cancellable{

	private Person owner;
	
	
	
	public Birthday(String name, LocalDateTime start, LocalDateTime finish, String place, ArrayList<Person> attendees,
			Person owner) {
		super(name, start, finish, place, attendees);
		this.owner = owner;
	}



	@Override
	public void printSummary() {
		System.out.println("Birthday:");
		System.out.println("Owner:" + owner);
		System.out.println(super.toString());
		System.out.println("---------");
		
	}
	
	@Override
	public void cancel() {
		System.out.println("Birthday Attendees are mailed..");
		
	}
	
	public Person getOwner() {
		return owner;
	}
	
	public void setOwner(Person owner) {
		this.owner = owner;
	}



	

}
