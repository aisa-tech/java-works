package main;

import java.time.LocalDateTime;
import java.util.ArrayList;

import model.Birthday;
import model.EventManager;
import model.Meeting;
import model.Person;
import model.Wedding;

public class Program {

	
	public static void main(String[] args) {
		
		//Birthday
		Person birthDayOwner = new Person("Henry", "Johnson");
		ArrayList<Person> birthAttendees = new ArrayList<Person>();
		birthAttendees.add(new Person("ahmet","mehmet"));
		birthAttendees.add(new Person("ayse","fatma"));
		
		Birthday birthday = new Birthday("Henry's Birthday",LocalDateTime.of(2021, 1, 14, 13, 0),
				LocalDateTime.of(2021, 1, 14, 16, 0),"ISTANBUL",birthAttendees,birthDayOwner);
				
		EventManager manager = new EventManager();
		manager.scheduleEvent(birthday);
		
		
		//Meeting
		ArrayList<Person> meetingAttendees = new ArrayList<Person>();
		meetingAttendees.add(new Person("JAck","jack"));
		meetingAttendees.add(new Person("Gokay","Gokay"));
		Meeting meeting = new Meeting("HR Meeting",LocalDateTime.of(2021, 1, 14, 13, 0),
				LocalDateTime.of(2021, 1, 14, 16, 0), "ANKARA", meetingAttendees, "New Salaries");
		
		manager.scheduleEvent(meeting);

		//Wedding
		
		ArrayList<Person> weddingAttendees = new ArrayList<Person>();
		weddingAttendees.add(new Person("Fatma","Gul"));
		weddingAttendees.add(new Person("Ahmet","Genc"));
		Person groom = new Person("Grrom", "Last Name");
		Person bride = new Person("Briddee", "Last Name");
		
		Wedding wedding = new Wedding("Brides Wedding", LocalDateTime.of(2021, 1, 14, 13, 0),
				LocalDateTime.of(2021, 1, 14, 16, 0), "IZMIR", weddingAttendees, groom, bride);
		
		
		manager.scheduleEvent(wedding);
		
		//Listing events:
		
		manager.listEvents();
		
		//Cancel Meeting
		
		manager.cancelEvent(birthday);
		
		//List new schedule
		
		manager.listEvents();
		
		
	}
	
	
	
}
