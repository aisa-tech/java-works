package primref;

import main.Car;

// Primitive versus reference type assignments
public class PrimRefMain {

	public static void main(String[] args) {
		
		
		//primitive assignments
		
		int x = 5;
		
		int y = 10;
		
		y=x;
		
		x+=2;
		
		System.out.println("x:" + x);
		System.out.println("y:" + y);
		
		//Reference type assignments
		
		
		Car c1 = new Car(2000, "Ford Fiesta", "Red");
		
		Car c2 = new Car(2010, "Volvo", "Black");
		c2 = c1;
				
		
		c1.setColor("Blue");
		
		System.out.println("c1:" + c1.getColor());
		System.out.println("c2:" + c2.getColor());
		
		
		
		c1.setYear(2003);
		c2 = c1;
		
		System.out.println("c1:" + c1.getYear());
		System.out.println("c2:" + c2.getYear());
		

		c2.setYear(2100);
		System.out.println(c1.year);
		System.out.println(c2.year);
		
		/*
		c1.year = 2010;
		System.out.println(c1.year);
		System.out.println(c2.year);
		
		
		c1 = c2;
		*/
		
		//c1 = null;
		
		c2 = new Car();
		
		// if c1 = null , code belowe will trhrow a null pointer exception
		//c1.getYear();
		
		
		String s1 = "ali veli";
		String s2 = s1;
		s1+=" added string";
		System.out.println(s1);
		System.out.println(s2);
		
	}
	
	
	
}
