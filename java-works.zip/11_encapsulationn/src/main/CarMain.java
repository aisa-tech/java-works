package main;

public class CarMain {

	
	public static void main(String[] args) {
		
		
		Car car1 = new Car(2010, "Opel Astra", "Black");
		
		System.out.println(car1.getInfo());
		System.out.println("-------------");
		
		
		car1.setYear(2015);
		System.out.println(car1.getInfo());
		
		System.out.println("-------");

		System.out.println(car1.getYear());
		System.out.println("-------");
		
		Car newCar = new Car();
		System.out.println(newCar.getInfo());
		System.out.println(newCar.getInfo());
	
	}
	
	
	
}
