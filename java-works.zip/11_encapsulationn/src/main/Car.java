package main;


//A class with private fields, a default constructor and related setters and 
//getter is called a POJO -> Plain Old Java Object  or 
// is also called a JavaBean

public class Car {

	public int year;
	private String model;
	private String color;
	
	
	public Car() {
		year = 2000;
		model = "Ford Fiesta";
		color = "Blue";
	}
	
	
	
	public Car(int year, String model, String color) {
		this.year = year;
		this.model = model;
		this.color = color;
	}




	//Encapsulation of the class
	
	public String getInfo() {
		String retVal = "Model: " + model + ", year:" + year + ", color:"  + color;
		return retVal;
	}
	
	//Setter
	public void setYear(int year){
		this.year =year;
	}
	//Getter
	public int getYear() {
		return this.year;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public void setColor(String color) {
		this.color = color;
	}
	
	public String getColor() {
		return color;
	}
	
	
}
