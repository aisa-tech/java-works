package staticexample;

public class MainClass {

	public static void main(String[] args) {
		
		Plane p1 = new Plane();
		Plane p2 = new Plane();
		Plane p3 = new Plane();
		
		System.out.println("NUmber of planes:" + Plane.getCount());
		
	}
	
	
}
