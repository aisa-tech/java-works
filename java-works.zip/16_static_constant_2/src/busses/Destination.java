package busses;

public enum Destination {
	ANKARA, ISTANBUL
}
