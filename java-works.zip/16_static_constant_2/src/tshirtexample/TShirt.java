package tshirtexample;

public class TShirt {

	//size = 0 -> small, size=1 -> medium , size=2 -> large
	
	public static final int SMALL = 0;
	public static final int MEDIUM = 1;
	public static final int LARGE = 2;
	
	
	private int size;
	
	public TShirt(int size) {
		this.size = size;
		
	}
	
	public double getCost() {
		
		switch (size) {
		case 0:
			return 3.0;
		case 1:
			return 4.0;

		default:
			return 5.0;
		}
		
		
	}
	
}
