package tshirtexample;

public class TshirtMain {

	public static void main(String[] args) {
		
		
		TShirt medThsirt = new TShirt(TShirt.MEDIUM);
		
		System.out.println(medThsirt.getCost());
		
		System.out.println(new TShirt(TShirt.LARGE).getCost());
		
		System.out.println("--------------");
		TShirt smallT = new TShirt(TShirt.SMALL);
		System.out.println(smallT.getCost());
		
	}
	
	
	
	
		
}
