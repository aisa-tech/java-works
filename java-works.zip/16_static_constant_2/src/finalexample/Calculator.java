package finalexample;

public class Calculator {

	//Below is a constant variable
	//convention static+final variables are written in upper case letter
	public static final double PI = 3.14;

	public final double START_NUMBER;
	
	
	public Calculator() {
		START_NUMBER = 300;
	}
	
}
