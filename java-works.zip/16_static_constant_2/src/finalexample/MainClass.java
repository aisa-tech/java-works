package finalexample;

public class MainClass {

	public static void main(String[] args) {
		
		
		Calculator c = new Calculator();
		
		
		
	}
	
	
	
}
