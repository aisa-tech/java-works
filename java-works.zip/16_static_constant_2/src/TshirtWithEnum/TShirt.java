package TshirtWithEnum;

public class TShirt {

	//size = 0 -> small, size=1 -> medium , size=2 -> large
	
	public enum SIZES{
		SMALL,MEDIUM,LARGE
	}
	
	private SIZES size;
	
	public TShirt(SIZES size) {
		this.size = size;
		
	}
	
	public double getCost() {
		
		switch (size) {
		case SMALL:
			return 2;
		case MEDIUM:
			return 3;

		default:
			return 4;
		}
		
	}
	
}
