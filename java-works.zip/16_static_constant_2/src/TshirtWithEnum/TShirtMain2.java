package TshirtWithEnum;

public class TShirtMain2 {


	
	public static void main(String[] args) {
		
		TShirt shirt1 = new TShirt(TShirt.SIZES.LARGE);
		System.out.println(shirt1.getCost());
		

		
	}
	
	
	
}
