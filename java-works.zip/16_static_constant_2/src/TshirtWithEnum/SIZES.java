package TshirtWithEnum;

public enum SIZES {

	 SMALL,MEDUIM,LARGE
	
	
	
}
