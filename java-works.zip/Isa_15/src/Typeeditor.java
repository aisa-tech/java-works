
public class Typeeditor {
	
	public int changeValue(int x) {
		x+=100;
		return x;
		
	}

	public Customer changeName(Customer customer , String newName) {
		customer.name = newName;
		return customer;	
		
	}
	public String changeString(String aString) {
		aString += "Added by new metghod ";
		return aString;
	}
	
	
	
	
}
