
public class TypeEditorMain {
	public static void main(String[] args) {
		
		int myNumber = 150;
		
		Typeeditor editor = new Typeeditor();
		editor.changeValue(myNumber);
		System.out.println(myNumber);
		
		System.out.println("--------------------");
		
		
		Customer cust1 = new Customer();
		cust1.name = "Isa";
		editor.changeName(cust1, "YILMAZ");
		System.out.println(cust1.name);
		
		System.out.println("--------------------");
			
	
		String originalName = "Murat";
		editor.changeString(originalName);
		System.out.println(originalName);
		
		
		
	}
	


}
