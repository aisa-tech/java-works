
public class Customer {
	
	public String name;
	

}
