package model;

import java.time.LocalDateTime;

public class Pilot {

	private long id;
	private String name;
	private LocalDateTime birthDate;
	private LocalDateTime jobStartDate;
	private String status;
	

	public Pilot() {
		// TODO Auto-generated constructor stub
	}

	
	
	
	public Pilot(long id, String name, LocalDateTime birthDate, LocalDateTime jobStartDate) {
		super();
		this.id = id;
		this.name = name;
		this.birthDate = birthDate;
		this.jobStartDate = jobStartDate;
	}


	public void setStatus(String status) {
		this.status = status;
	}
	
	public String getStatus() {
		return status;
	}

	public String displayInformation() {

		return String.format("Pilot Id is %d, Pilot name is %s, Age is %d, Experience Year is %d, status is %s", id, name, getAge(),
				getExperienceInYears(), status);
	}
	
	public int getAge() {
		return LocalDateTime.now().getYear() - birthDate.getYear();
	}
	
	public int getExperienceInYears() {
		
		int elapsed = LocalDateTime.now().getYear() - jobStartDate.getYear();
		return elapsed;
		
		
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	

}
