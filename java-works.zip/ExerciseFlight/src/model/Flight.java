package model;

import java.time.LocalDateTime;

public class Flight {

	private long id;
	private String destination;
	private String departure;
	private LocalDateTime departureTime;
	private LocalDateTime arrivalTime;
	private Plane plane;
	private Pilot[] pilots;
	private boolean cancelled;

	public Flight() {
		// TODO Auto-generated constructor stub
	}

	public Flight(long id, String destination, String departure, LocalDateTime departureTime, LocalDateTime arrivalTime,
			Pilot[] pilots, Plane plane) {
		this.id = id;
		this.destination = destination;
		this.departure = departure;
		this.departureTime = departureTime;
		this.arrivalTime = arrivalTime;
		this.pilots = pilots;
		this.plane = plane;

	}

	public void reassignPilot(Pilot newPilot) {
		System.out.println("reassign pilot");
		if(pilots!=null) {
			for (int i = 0; i < pilots.length; i++) {
				if(pilots[i].getStatus().equals(newPilot.getStatus())) {
					pilots[i] = newPilot;
					break;
				}
			}
			
		}
	}
	public String displayInformation() {

		
		String out = String.format("Flight Info\nId is %d, Destination is %s, Departure Time is %s, Arrival Time is %s, Plane Name is %s",
				id, destination, departureTime, arrivalTime,plane.getName());
		out+="\nPilots:";
		for (Pilot pilot : pilots) {
			out+="\n"+pilot.displayInformation();
		}
		
		return out;
	}

	public void cancelFlight(boolean cancelled) {

		if (cancelled == true) {
			
			System.out.println("Flight is already cancelled");
		} else {
			cancelled = true;
			System.out.println("Flight is not cancelled");
		}

	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getDeparture() {
		return departure;
	}

	public void setDeparture(String departure) {
		this.departure = departure;
	}

	
	public LocalDateTime getDepartureTime() {
		return departureTime;
	}

	public void setDepartureTime(LocalDateTime departureTime) {
		this.departureTime = departureTime;
	}

	public LocalDateTime getArrivalTime() {
		return arrivalTime;
	}

	public void setArrivalTime(LocalDateTime arrivalTime) {
		this.arrivalTime = arrivalTime;
	}

	
	public boolean isCancelled() {
		return cancelled;
	}

	public void setCancelled(boolean cancelled) {
		this.cancelled = cancelled;
	}
	
	public void setPilots(Pilot[] pilots) {
		this.pilots = pilots;
	}
	public Plane getPlane() {
		return plane;
	}
	
	public Pilot[] getPilots() {
		return pilots;
	}
	
	

}
