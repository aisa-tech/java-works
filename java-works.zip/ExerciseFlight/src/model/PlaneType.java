package model;

public enum PlaneType {

	SMALLJET, LARGEJET, CARGO
	
}
