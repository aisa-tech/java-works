package model;

public enum PilotStatus {

	PRIMARY, SECONDARY
	
}
