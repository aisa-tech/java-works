package main;

public class TestMath {

	public static void main(String[] args) {
		
		//java.lang
		//Math class example
		//All methods and fields of Math are static
		 double pi =  Math.PI;
		 System.out.println(pi);
		
	}
	
	
	
}
