package main;

import java.util.ArrayList;

public class IsaProductInfo {
	
	public static void main(String[] args) {
		
		ArrayList<ProductInfo>products = ProductInfo.getProducts();
		
		ArrayList<ProductInfo>product18 = new ArrayList<ProductInfo>();
		ArrayList<ProductInfo>product01 = new ArrayList<ProductInfo>();
		
		for (ProductInfo productInfo : products) {
			if (ProductInfo.getVat() == 0.18) {
				product18.add(productInfo);

				
			}else if(ProductInfo.getVat()== 0.01) {
				product01.add(productInfo);
				
			}
			
			
			
		}
		
		System.out.println("product18");
		for (ProductInfo productInfo : product18) {
			System.out.println(productInfo.getProductName());
			
		}
		//System.out.println("---------------");
		System.out.println("product01");
		
		for (ProductInfo productInfo : product01) {
			System.out.println(productInfo.getProductName());
			
		}
		
		
		for (ProductInfo productInfo : products) {
			if (productInfo.isAvailable()==true) {
				ArrayList<ProductInfo> productsAvailable = null;
				productsAvailable.add(productInfo);
				
			}else {
				
			}
			
		}
		
	}

}
