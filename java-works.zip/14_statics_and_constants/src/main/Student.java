package main;

public class Student {

	private String name;
	
	public static String A_STATIC_VALUE = "Some value";
	
	public static void main(String[] args) {
		
		//The codes below has compiler errors
		//Because static methods cannot access instance variables or methods directly.
		//setName("ali");
		//String name = getName();
		
		
		Student stu = new Student();
		stu.setName("ali");
		
		System.out.println(A_STATIC_VALUE);
		
		A_STATIC_VALUE = "Some other value";
		
		output();
		
	}
	
	
	public static void output() {
		System.out.println("Static method output");
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	
	
}
