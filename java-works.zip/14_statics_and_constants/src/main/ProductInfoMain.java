package main;

import java.util.ArrayList;

public class ProductInfoMain {

	public static void main(String[] args) {
		
		ArrayList<ProductInfo> products =  ProductInfo.getProducts();
		
		ArrayList<ProductInfo> prods18perc = new ArrayList<ProductInfo>();
		ArrayList<ProductInfo> prods01perc = new ArrayList<ProductInfo>();
		
		for (ProductInfo productInfo : products) {
			
			if(productInfo.getVat()== 0.18) {
				prods18perc.add(productInfo);
			}else if(productInfo.getVat()==0.01) {
				prods01perc.add((productInfo));
			}
			
			
		}
		
		System.out.println("18 % products");
		
		for (ProductInfo productInfo : prods18perc) {
			System.out.println(productInfo.getProductName());
		}
		
		System.out.println("01 % products");
		
		for (ProductInfo productInfo : prods01perc) {
			System.out.println(productInfo.getProductName());
		}
		
		
		
		
	}
	
	
	
	
	
	
	
}
