package main;

public class TestCalculator {

	public static void main(String[] args) {
		
		// pi number is shared by all instances of Calculator
		//We never access static fields or methos using instances as below
		System.out.println(Calculator.pi);
		Calculator.pi = 5;
		
		System.out.println(Calculator.pi);
		
		Calculator c = new Calculator();
		
		c.pi = 2;
		
		Calculator c2 = new Calculator();
		System.out.println(c2.pi);
		
		
		Calculator.pi = 100;
		
		System.out.println(c.pi);
		System.out.println(c2.pi);
		
		System.out.println(Calculator.makeSum(34, 20));
	
		
		
		
		
	}
	
	
	
}
