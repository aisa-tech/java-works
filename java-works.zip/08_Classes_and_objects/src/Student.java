
public class Student {

	//state of the object
	//global variables
	long id;
	String name;
	String course1;
	
	
	//Default constructor
	Student(){
		name = "no name";
		
	}
	
	//Non-default constructor
	
	Student(long _id, String _name){
		id = _id;
		name =_name;
	}
	
	
	//behaviour of the object
	//methods
	
	void changeName(String newName) {
		name = newName;
		System.out.println("Student's name changed to " + name);
	}
	
	void registerToCourse(String courseName) {
		course1 = courseName;
		System.out.println("The student registered to " + courseName);

				
	}
	
	String getInfo() {
		String output = "";
		output += "Student ID:" + id;
		output +=", Student Name:" + name;
		output+= ", Course 1 registered:" + course1;
		
		return output;	
	}
	
	
}
