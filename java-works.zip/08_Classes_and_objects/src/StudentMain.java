
public class StudentMain {

	
	public static void main(String[] args) {
		
		
	
		System.out.println("Welcome to the registration app.");
		
		Student s = new Student(2554,"altug");
		
		System.out.println("Student name:" + s.name);
		s.changeName("Mehmet");
		s.registerToCourse("Math-101");
		
		System.out.println(s.getInfo());
		
		
		
		
	}
	
	
	
}
