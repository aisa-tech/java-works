package question1;

public class House extends GameObject{

	public House(int posX, int posY) {
		super(posX, posY);
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "House";
	}

}
