package question1;

public class Player extends GameObject implements Movable{
	private double previousDistance;
	
	public double getPreviousDistance() {
		return previousDistance;
	}

	public void setPreviousDistance(double previousDistance) {
		this.previousDistance = previousDistance;
	}

	
	

	@Override
	public String toString() {
		return "Player";
	}

	public Player(int posX, int posY) {
		super(posX, posY);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void move(int x, int y) {
		// TODO Auto-generated method stub
		setPosX(x);
		setPosY(y);
		
	}
	
	
	
	

}
