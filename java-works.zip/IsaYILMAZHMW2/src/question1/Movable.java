package question1;

public interface Movable {
	
	public void move(int x, int y);

}
