package question1;

import java.awt.dnd.peer.DropTargetPeer;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Game {
	
	private int boardSize;
	private Player player;
	private Robot robot;
	private Treasure treasure;
	

	
	private ArrayList<GameObject>gameObjectList = new ArrayList<GameObject>();
	int tree1X;
	int tree1Y;
	int tree2X;
	int tree2Y;

	public Game(int boardSize) {
		
		
	
		this.boardSize = boardSize;
		Random rnd = new Random();
		treasure = new Treasure(rnd.nextInt(boardSize), rnd.nextInt(boardSize));
		player = new Player(rnd.nextInt(boardSize), rnd.nextInt(boardSize));
		robot = new Robot(rnd.nextInt(boardSize), rnd.nextInt(boardSize));
		House house = new House(rnd.nextInt(boardSize), rnd.nextInt(boardSize));
		this.tree1X= rnd.nextInt(boardSize);
		this.tree1Y=rnd.nextInt(boardSize);
		this.tree2X= rnd.nextInt(boardSize);
		this.tree2Y=rnd.nextInt(boardSize);
		Tree tree1 = new Tree(tree1X,tree1Y);
		Tree tree2 = new Tree(tree2X,tree2Y);
		gameObjectList.add(house);
		gameObjectList.add(tree1);
		gameObjectList.add(tree2);
		
		
	}

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Please enter the board size:");
		int boardSize = sc.nextInt();
		Game game = new Game(boardSize);
		game.play();
	
	}

	public void play() {
		
		Scanner sc =new Scanner(System.in);
		Random rnd = new Random();
	
		int count = 0;
	
		do {
		count++;
		
		System.out.println("Turn : " + count);
		
		System.out.println("You are in position : " + "x: "+ player.getPosX() + " y: "+player.getPosY() );
		
		if(player.getPosX()==treasure.getPosX()&&player.getPosY()==treasure.getPosY()) {
			System.out.println("You are on treasure.You got the game...");
		}
		
		System.out.println("Please enter position x for player:");
		int x = sc.nextInt(boardSize);
		System.out.println("Please enter position y for player:");
		int y = sc.nextInt(boardSize);

		player.move(x, y);
		if (player.getPreviousDistance() > calculateDistance()) {
			System.out.println("You are getting closer to the treasure");
		}
		else if (player.getPreviousDistance() < calculateDistance())  {
			System.out.println("You are getting far to the treasure");
		}else {
			System.out.println("You are on treasure.");
		}
	
		if(x== treasure.getPosX() && y == treasure.getPosY()) {
			System.out.println("You found Treasure,you won the game..");
			break;
			
		
	
		}else if(x==robot.getPosX() && y == robot.getPosY()) {
			System.out.println("You lost game..");
			break;
		}else if (x==tree1X || x== tree2X && y==tree1Y || y==tree2Y ) {
			System.out.println("You need to wait...");
			
			
			robot.move(rnd.nextInt(boardSize), rnd.nextInt(boardSize));
			
		}
		robot.move(rnd.nextInt(boardSize), rnd.nextInt(boardSize));
		System.out.println("Robot position: "+robot.getPosX() + robot.getPosY());
		
		if(robot.getPosX() == player.getPosX() && robot.getPosY() == player.getPosY()) {
			System.out.println("You lost game...");
			break;
			
		}else if(robot.getPosX()==treasure.getPosX() && robot.getPosY()==treasure.getPosY()) {
			System.out.println("Robot found the treasure!");
			break;	
		}		
		}while(count < 10);

	
	}
	
	private double calculateDistance() {
		double distanceSquare = (player.getPosX()-treasure.getPosX())*(player.getPosY()-treasure.getPosY());
		double distance = Math.sqrt(distanceSquare);
		return distance ;
				
	}

}

