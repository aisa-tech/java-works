package question1;

public class Tree extends GameObject{

	public Tree(int posX, int posY) {
		super(posX, posY);
		// TODO Auto-generated constructor stub
	}
	
	
	@Override
	public String toString() {
		return "Tree";
	}
	


	

}
