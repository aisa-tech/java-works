package question1;

public class Robot extends GameObject implements Movable{
	

	public Robot(int posX, int posY) {
		super(posX, posY);
		// TODO Auto-generated constructor stub
	}


	@Override
	public String toString() {
		return "Robot";
	}


	@Override
	public void move(int x, int y) {
		// TODO Auto-generated method stub
		setPosX(x);
		setPosY(y);
	

		
	}
	

}
