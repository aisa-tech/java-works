package question1;

public class Treasure extends GameObject{

	

	public Treasure(int posX, int posY) {
		super(posX, posY);
		
		
	}
	
	@Override
	public String toString() {
		return "Treasure";
	}
	


}
