package example2;

public class Calculator {

	public void divide(int x1, int x2) {
		System.out.println((x1/x2));
	}
	
	
}
