package example2;

public class MainClaculator {

	public static void main(String[] args) {
		
		Calculator calc = new Calculator();
		
		try {
			//calc.divide(4, 0);
			
			int[] numbers = new int[2];
			System.out.println(numbers[5]);
		//Exceptions must be catched from more specific classes to more general classes	
		}catch (ArithmeticException e) {
			
			System.out.println("2nd number is zero");
		} 
		
		catch (Exception e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.out.println("Array index aout of bounds exception");
			
		}

		
		
		
		
	}
	
	
	
}
