package example3;

public class AnotherExceptionalClass {

	
	public static void main(String[] args) {
		
		AnotherExceptionalClass obj = new AnotherExceptionalClass();
		//All unchecked exceptions (extends RuntimeException) doesn't need to be handled.
		obj.test(new int[] {1});
		
		
		
	}
	
	
	public void test(int[] numbers){
		
		if(numbers.length==3) {
			System.out.println(numbers[2]);
		}else {
			throw new ArrayIndexOutOfBoundsException();
		}
		
	}
	
	
	
}
