package example3;

public class CalculatorMain2 {

	public static void main(String[] args) {
		
		Calculator calc = new Calculator();
		
		/*
		int x = 100;
		
		for (int i = 0; i < 100; i++) {
			System.out.println(i);
		}
		*/
		
		//All thrown/declared checked exceptions MUST BE handled: must be put inside try-catch block
		try {
			calc.divide(4, 0);
			
		} catch (Exception e) {
			System.out.println("catch block...");
			e.printStackTrace();
		}
		
		
		
		
	}
	
	
	
}
