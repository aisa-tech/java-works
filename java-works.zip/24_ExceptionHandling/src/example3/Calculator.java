package example3;

public class Calculator {

	public void divide(int x1, int x2) throws Exception{
		
		if(x2==0) {
			throw new Exception();
		}else {
			System.out.println((x1/x2));
		}
		
		
	}
	
	
}
