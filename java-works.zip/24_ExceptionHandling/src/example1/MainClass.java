package example1;

import java.util.ArrayList;

public class MainClass {

	public static void main(String[] args) {
		
		int x1 = 12;
		int x2 = 0;
		
		
		try {
			System.out.println((x1/x2));
			System.out.println("More code lines in try block..");
			
		}
		catch (ArithmeticException ex) {
			//ex.printStackTrace();
			System.out.println("Number cannot be divided by zero");
		}finally {
			// Always execute
			System.out.println("Finally block");
			//Resource cleaning
		}
		
		
		
		
		System.out.println("More code lines..");
		
		
	}
	
	
	
	
	
	
}
