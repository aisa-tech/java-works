package example5;

import java.util.Scanner;

public class TestExp {

	
	
	public static void main(String[] args) {
		
		
		Scanner sc = new Scanner(System.in);
		
		
		boolean valid = false;
		
		while(!valid) {
			try {
				System.out.println("Enter x:");
	
				Integer.parseInt(sc.next());

				valid = true;
			} catch (NumberFormatException e) {
				System.out.println("Not valid");
				
			}
		}
		System.out.println("number valid!");
		
	
		
		
	}
	
	
	
}
