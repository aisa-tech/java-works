package example4;

public class MainDivideZeroExc {

	public static void main(String[] args) {
		
		Calculator calc = new Calculator();
		
		
		try {
			calc.divide(4, 0);
		} catch (DivideByZeroException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
		
		
		
		
	}
	
	
	
	
}
