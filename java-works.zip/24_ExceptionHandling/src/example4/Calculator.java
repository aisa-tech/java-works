package example4;

public class Calculator {

	public void divide(int x1, int x2) throws DivideByZeroException{
		
		if(x2==0) {
			throw new DivideByZeroException("Number cannot be divided by zero.");
		}else {
			System.out.println((x1/x2));
		}
		
	
	}
	
	
}
