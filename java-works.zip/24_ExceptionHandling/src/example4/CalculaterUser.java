package example4;

public class CalculaterUser {

	
	
	public void makeSomeCalculation(int x, int y) throws DivideByZeroException {
		Calculator calc = new Calculator();
		calc.divide(x, y);
	}
	
	
	
}
