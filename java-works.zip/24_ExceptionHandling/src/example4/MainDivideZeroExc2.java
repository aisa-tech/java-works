package example4;

public class MainDivideZeroExc2 {

	//Never rethrow checked exceptions in main method,
	//always handle them -> use try-catch block
	public static void main(String[] args) throws DivideByZeroException  {
		
		Calculator calc = new Calculator();
		
		CalculaterUser usr = new CalculaterUser();
		usr.makeSomeCalculation(3, 0);
		System.out.println("more code...");
		
		
		
	}
	
	
	
	
}
