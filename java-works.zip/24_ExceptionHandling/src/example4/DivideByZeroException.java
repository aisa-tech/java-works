package example4;

public class DivideByZeroException extends Exception{

	public DivideByZeroException(String message) {
		super(message);
	}
	
	
}
