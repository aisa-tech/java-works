package main;

public class Customer {

	public String name;
	
}
