package main;

public class TypeEditorMain {

	public static void main(String[] args) {
		
		
		//Pass-By-Value
		//When primitive types are passed to methods as parameters
		//their value is COPIED.
		int myNumber = 150;
		
		TypeEditor editor = new TypeEditor();
		editor.changeValue(myNumber);
		
		//But below myNumber changes as the copy is returned and assigned to myNumber again
		//myNumber = editor.changeValue(myNumber);
		
		
		System.out.println("value:" + myNumber);
		
		System.out.println("----------");
		
		//Pass-By-Reference
		//When reference types are passed to methods as parameters
		//their reference is COPIED, so the original object chnages.
		Customer cust1 = new Customer();
		cust1.name = "altug";
		
		editor.changeName(cust1, "ali");
		
		System.out.println(cust1.name);
		
		System.out.println("--------");
		//Strings are reference types BUT act like primitive types.
		String originalValue = "test ";
		editor.changeStr(originalValue);
		System.out.println(originalValue);
		
		
		
	}
	
	
	
}
