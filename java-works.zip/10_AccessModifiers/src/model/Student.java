package model;

//Java classes can only be public or without any access modifier
//If Student class had default access, then it wouldn't be accessable in MainClass in main package.
public class Student {

	private long id;
	private String name;
	protected String city;
	
	//default access = protected
	int age;
	
	protected void testProtected() {
		
	}
	
	private void displayInformation() {
		id = 2300;
		
		
		
		
	}
	
	
	
}
