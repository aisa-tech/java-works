package model;

public class TestStudent {

	
	public void test() {
		
		Student stu = new Student();
		System.out.println(stu.city);
		System.out.println(stu.age);
		stu.testProtected();
	}
	
	
	
	
}
