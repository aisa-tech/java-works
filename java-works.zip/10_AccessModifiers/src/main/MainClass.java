package main;

import model.Student;

public class MainClass {

	
	public static void main(String[] args) {
		
		Student stu = new Student();
		
		// displayInformation() and id are private so not visible
		//stu.displayInformation();
		//System.out.println(stu.id);
		
		//The fields below are protected so cannot be accessed from any type in main package
		//stu.city
		//stu.testProtected()
		
		//The age field has default access, so not accessable from any type in any other package
		//System.out.println(stu.age);
		
	}
	
	
	
}
