package sinavDenem;

public class EventManager {
	
	public void scheduleEvent(Event evt) {
		
	}

	
	public void cancelEvent(Cancellable cancellable) {
		
	}
}
