package sinavDenem;

public interface Cancellable {
	
	public void cancelEvent();

}
