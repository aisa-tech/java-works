package sinavDenem;

import java.time.LocalDateTime;
import java.util.ArrayList;

public class Wedding extends Event{
	
	
	
	public Wedding(String name, LocalDateTime starttime, LocalDateTime finishtime, String place,
			ArrayList<Person> attendees, Person groom, Person bride) {
		super(name, starttime, finishtime, place, attendees);
		this.groom = groom;
		this.bride = bride;
	}



	private Person groom;
	private Person bride;
	
	
	
	@Override
	public void printSummary() {
		System.out.println("Weeding:");
		System.out.println("Bride:"+bride);
		System.out.println("Groom:"+ groom);
		System.out.println(super.toString());
		System.out.println("-------");
		
	}
	
	
	
	

}
