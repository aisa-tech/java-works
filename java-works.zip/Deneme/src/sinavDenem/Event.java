package sinavDenem;

import java.time.LocalDateTime;
import java.util.ArrayList;

public abstract class Event {
	
	private String name;
	private LocalDateTime starttime;
	private LocalDateTime finishtime;
	private String place;
	
	private ArrayList<Person>attendees= new ArrayList<>();
	
	
	public Event() {
		//attendees = new ArrayList<Person>();
	}
	
	
	public Event(String name, LocalDateTime starttime, LocalDateTime finishtime, String place,
			ArrayList<Person> attendees) {
		super();
		this.name = name;
		this.starttime = starttime;
		this.finishtime = finishtime;
		this.place = place;
		this.attendees = attendees;
	}


	@Override
	public String toString() {
		return "Event [name=" + name + ", starttime=" + starttime + ", finishtime=" + finishtime + ", place=" + place
				+ ", attendees=" + attendees + "]";
	}
	
	
	
	
	

	public abstract void printSummary();
	
	
	
	
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Event other = (Event) obj;
		if (attendees == null) {
			if (other.attendees != null)
				return false;
		} else if (!attendees.equals(other.attendees))
			return false;
		if (finishtime == null) {
			if (other.finishtime != null)
				return false;
		} else if (!finishtime.equals(other.finishtime))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (place == null) {
			if (other.place != null)
				return false;
		} else if (!place.equals(other.place))
			return false;
		if (starttime == null) {
			if (other.starttime != null)
				return false;
		} else if (!starttime.equals(other.starttime))
			return false;
		return true;
	}





	public String getName() {
		return name;
	}





	public void setName(String name) {
		this.name = name;
	}





	public LocalDateTime getStarttime() {
		return starttime;
	}





	public void setStarttime(LocalDateTime starttime) {
		this.starttime = starttime;
	}





	public LocalDateTime getFinishtime() {
		return finishtime;
	}





	public void setFinishtime(LocalDateTime finishtime) {
		this.finishtime = finishtime;
	}





	public String getPlace() {
		return place;
	}





	public void setPlace(String place) {
		this.place = place;
	}





	public ArrayList<Person> getAttendees() {
		return attendees;
	}





	public void setAttendees(ArrayList<Person> attendees) {
		this.attendees = attendees;
	}


	








	
	

}
