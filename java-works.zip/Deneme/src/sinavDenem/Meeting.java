package sinavDenem;

import java.time.LocalDateTime;
import java.util.ArrayList;

public class Meeting extends Event implements Cancellable{
	
	private String subject;
	

	
	
	
	public Meeting(String name, LocalDateTime starttime, LocalDateTime finishtime, String place,
			ArrayList<Person> attendees, String subject) {
		super(name, starttime, finishtime, place, attendees);
		this.subject = subject;
	}


	@Override
	public void printSummary() {
		
		System.out.println("Subject:"+subject);
		
		System.out.println(super.toString());
		System.out.println("-------");
	}


	@Override
	public void cancelEvent() {
		System.out.println("Meeting calcelled..");
		
	}
	
	

}
