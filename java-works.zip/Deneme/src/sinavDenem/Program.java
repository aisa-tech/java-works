package sinavDenem;

import java.time.LocalDateTime;
import java.util.ArrayList;

public class Program {
	
	public static void main(String[] args) {
		
		
		ArrayList<Person>weddingAttendees= new ArrayList<>();
		weddingAttendees.add(new Person("Isa", "YILMAZ"));
		weddingAttendees.add(new Person("Ali", "KUCUK"));
		Person groom = new Person("Isa", "Doktor");
		Person bride = new Person("Doktor", "Gelin");
		
		ArrayList<Person>atteneees = new ArrayList<>();
		atteneees.add(new Person("Ayse", "YILMAZ"));
		
		Wedding wedding = new Wedding("ISA", LocalDateTime.of(2020, 1, 28, 19, 0),
				LocalDateTime.of(2020, 1, 28, 22, 0), "Izmir", atteneees, groom, bride);
		

		
		

		
		
		
		
	}

}
