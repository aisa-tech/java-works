package sinavDenem;

import java.time.LocalDateTime;
import java.util.ArrayList;

public class Birthday extends Event implements Cancellable{
	
	private Person owner;

	
	
	
	public Birthday(String name, LocalDateTime starttime, LocalDateTime finishtime, String place,
			ArrayList<Person> attendees, Person owner) {
		super(name, starttime, finishtime, place, attendees);
		this.owner = owner;
	}

	@Override
	public void printSummary() {
		System.out.println("Birthday:");
		System.out.println("Owner:"+owner);

		System.out.println(super.toString());
		System.out.println("-------");
		
	}

	@Override
	public void cancelEvent() {
		// TODO Auto-generated method stub
		
	}



}
