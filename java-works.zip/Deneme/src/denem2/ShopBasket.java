package denem2;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class ShopBasket {

	
	public static void main(String[] args) {
		
		
		double total = 0;
		
		try(
				
				BufferedReader reader = new BufferedReader(new FileReader("thelist.txt"));
				
				)
		{
			
			
			String line ="";
			while((line=reader.readLine())!=null) {
				
					String[] parts = line.split(":");
					total+= Double.valueOf(parts[1])* Double.valueOf(parts[2]);
					
					

			}
			
			System.out.println("The total is " + total);
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		
		
	}
}
