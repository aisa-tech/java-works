
public class SimpleArrays {

	public static void main(String[] args) {
		// new int[5] -> 0 - 4
		int[] numbers = new int[5];
		numbers[0] = 23;
		numbers[1] = 12;
		numbers[2] = 45;
		numbers[3] = 56;
		numbers[4] = 80;
		
		System.out.println(numbers[0]);
		System.out.println(numbers[2]);
		
		//The code below throws an error because of exceeding the size of the array.
		//System.out.println(numbers[5]);
		
		System.out.println("Length of numbers:" + numbers.length);
		
		int[] numbers2 = {5,6,7,8,9};
		
		
		for (int i = 0; i < numbers2.length; i++) {
			System.out.println(numbers2[i]);
		}
		
		System.out.println("----------");
		//Java foreach = Enhanced For loop
		
		for (int i : numbers2) {
			System.out.println(i);
		}
		
		//String arrays:
		
		String[] names = {"jack","john","henry"};
		
		
		for (String name : names) {
			System.out.println(name);
		}
		
		System.out.println("----------------");
		//Default values of Array Elements
		
		int[] numbers3 = new int[5];
		
		for (int i : numbers3) {
			System.out.println(i);
		}
		
		System.out.println("----------------");
		
		boolean[] bools = new boolean[3];
		
		for (boolean b : bools) {
			System.out.println(b);
		}
		
		//When initialized, Array members are assigned default values:
		// int -> 0
		//boolean -> false
		//char => 0
		//double -> 0.0
		//String -> null (Pyhton NaN, null)
		
		// All reference types array members are assigned null by default
		System.out.println("----------");
		String[] cities = new String[5];
		
		for (String city : cities) {
			System.out.println(city);
		}
		
		
		
		
		
	}
	
	
	
	
	
}
