
public class MultiDimensionalArray {

	
	public static void main(String[] args) {
		int[] numsss = {3,3,3,3,3,3,3};
		//Array of Arrays
		int[][] intMulti = new int[3][];
		
		intMulti[0] = new int[] {2,3};
		intMulti[1] = new int[] {3,3,3};
		intMulti[2] = numsss;
		
		for (int i = 0; i < intMulti.length; i++) {
			for (int j = 0; j < intMulti[i].length; j++) {
				System.out.println(i+ "," + j + " -- " + intMulti[i][j]);
			}
		}
		System.out.println("-----------------------");
		//Cities and districts:
		
		//2 dimensional String array
		// Dimension 1: for cities (ex: ankara, izmir, istanbul)
		// Dimension 2: for districts (istanbul: kadikoy, beyoglu, tuzla)
		// 0 -> ist, 1-> ank, 2-> izmir
		
		String[][] districts = new String[3][];
		
		districts[0] = new String[] {"kadikoy","besiktas","beyoglu","tuzla"};
		districts[1] = new String[] {"GOP","cankaya","yenimahalle"};
		districts[2] = new String[] {"Karsiyaka","Goztepe"};
		
		
		/*
		 * for (String[] city : districts) { for (String district : city) {
		 * System.out.println(district); } }
		 */
		
	
	  for (int i = 0; i < districts.length; i++) {
	  
	  if(i==0) System.out.println("ISTANBUL:"); else if(i==1)
	  System.out.println("ANKARA:"); else System.out.println("IZMIR:");
	  
	  System.out.println("---------------");
	  
	  
	  for (int j = 0; j < districts[i].length; j++) { System.out.println("\t" +
	  districts[i][j]); }
	  
	  
	  
	  
	  }
	 
		
	String date = "2000-2002";
	System.out.println(date.substring(0,4));
		
	int year = Integer.valueOf(date.substring(0,4));
		
		
	}
	
	
	
	
	
}
