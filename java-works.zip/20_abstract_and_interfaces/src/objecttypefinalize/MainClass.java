package objecttypefinalize;

public class MainClass {

	public static void main(String[] args) {
		
		
		Person person = new Person();
		person.name = "altug";
		
		System.out.println("Person initialized...");

		System.out.println("More code invocation");
		
		System.out.println("More code invocation");
		System.out.println("More code invocation");
		System.out.println("More code invocation");
		
		person = null;
		
		System.out.println("More code invocation");
		System.out.println("More code invocation");
		System.out.println("More code invocation");
		
		System.gc();
		
		
		
	}
	
	
	
	
}
