package objecttypefinalize;

public class Person {

	public String name;
	
	
	@Override
	protected void finalize() throws Throwable {
		super.finalize();
		System.out.println("Person cleared from memory");
		
		
	}
	
	
}
