package abstractexample;

public class GradStudent extends Student{

	
	private String thesisStubject;
	
	
	
	public GradStudent(int id, String name, String[] courses, String thesisStubject) {
		super(id, name, courses);
		this.thesisStubject = thesisStubject;
	}
	
	
	
	








	@Override
	public void study(String start, String finish) {
		System.out.println("Grad Student " + this.getName() + 
				" studies for " 
				+ thesisStubject 
				+ " from "
				+ start  
				+ " to " 
				+ finish);
		
	}
	
	
	public String getThesisStubject() {
		return thesisStubject;
	}

	public void setThesisStubject(String thesisStubject) {
		this.thesisStubject = thesisStubject;
	}
	
	
	
}
