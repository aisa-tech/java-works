package abstractexample;

public class MainClass {

	
	public static void main(String[] args) {
		
		//In our case, we'll never need to initialize the Student class
		//Student stu = new Student();
		
		//We cannot instantiate abstract classes
		//Student stu1 = new Student();
		
		
		Student grdStu1 = new GradStudent(1111,"altug",new String[] {"HIST","ECON"},"Social Phenomena");
		Student unStu2 = new UndergradStudent(2222,"ayse",new String[] {"CS","MATH"},"Clustering");
		System.out.println("-------");
		grdStu1.study("Sabah", "aksam");

		System.out.println("-------");
		grdStu1.study("13:00", "14:00");
		
		unStu2.study("16:00", "23:00");
		
	}
	
	
}
