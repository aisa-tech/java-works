package abstractexample;

public class UndergradStudent extends Student{

	private String projectSubject;

	public UndergradStudent(int id, String name, String[] courses, String projectSubject) {
		super(id, name, courses);
		this.projectSubject = projectSubject;
	}

	
	
	public String getProjectSubject() {
		return projectSubject;
	}

	public void setProjectSubject(String projectSubject) {
		this.projectSubject = projectSubject;
	}

	@Override
	public void study(String start, String finish) {
		System.out.println("Undergrad Student " + this.getName() + 
				" studies for " 
				+ projectSubject 
				+ " from "
				+ start  
				+ " to " 
				+ finish);
		
	}
	
	
}
