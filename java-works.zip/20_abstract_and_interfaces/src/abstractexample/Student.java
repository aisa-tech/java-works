package abstractexample;

public abstract class Student {
	
	private int id;
	private String name;
	private String[] courses;


	public Student(int id, String name, String[] courses) {
		super();
		this.id = id;
		this.name = name;
		this.courses = courses;
	}
	
	//abstract methods do not have method body
	//abstract methods must be implemented /overridden in the first concrete subclass
	public abstract void study(String start,String finish);

	
	
	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String[] getCourses() {
		return courses;
	}


	public void setCourses(String[] courses) {
		this.courses = courses;
	}
	
	
	
	
	
	
}
