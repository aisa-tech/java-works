package interfaceexample;

public class ZooKeeper {
	
	public void train(Trainable trainable) {
		trainable.howToTrain();
	}
	
	
	
	
}
