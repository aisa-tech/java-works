package interfaceexample;

public class Cattle extends Animal implements Eatable{

	@Override
	public void makeSound() {
		System.out.println("Cattle sound");
		
	}
	
	@Override
	public void howToEat() {
		System.out.println("Beef barbeque..");
		
	}

}
