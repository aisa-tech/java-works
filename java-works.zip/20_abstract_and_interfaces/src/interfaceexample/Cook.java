package interfaceexample;

public class Cook {

	
	public void cookFood(Eatable eatable) {
		
		eatable.howToEat();
		
		
	}
	
	
	
}
