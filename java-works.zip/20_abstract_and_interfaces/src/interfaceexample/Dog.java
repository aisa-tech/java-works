package interfaceexample;

public class Dog extends Animal implements Trainable{

	
	@Override
	public void makeSound() {
		System.out.println("Dog sound");
		
	}
	
	@Override
	public void howToTrain() {
		System.out.println("Dog is trained");
		
	}
	
}
