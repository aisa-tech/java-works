package interfaceexample;

public interface Trainable {

	
	public void howToTrain();
}
