package interfaceexample;

public interface Eatable {

	public static final int x = 1;
	
	public void howToEat();
	
}
