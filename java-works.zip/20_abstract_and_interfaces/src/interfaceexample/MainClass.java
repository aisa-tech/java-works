package interfaceexample;

public class MainClass {

	
	public static void main(String[] args) {
		
		//Polymorphic instantiations of Cat and Chicken.
		//Animal cat1 = new Cat();
		Eatable chicken1 = new Chicken();
		

		Chicken chicken2 = new Chicken();
		
		
		Animal cat1 = new Cat();
		
		Dog dog1 = new Dog();
		
		Cattle cattle1 = new Cattle();
		
		
		Cook cook = new Cook();
		
		ZooKeeper keeper = new ZooKeeper();
		
		
		cook.cookFood(cattle1);
		cook.cookFood(chicken2);
		
		keeper.train((Trainable)cat1);
		
		
	}
	
	
	
}
