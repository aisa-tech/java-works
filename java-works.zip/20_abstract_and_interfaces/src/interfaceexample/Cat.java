package interfaceexample;

public class Cat extends Animal implements Trainable{

	@Override
	public void makeSound() {
		System.out.println("Cat sound..");
		
	}

	@Override
	public void howToTrain() {
		System.out.println("Cat is trained");
		
	}

}
