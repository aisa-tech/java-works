package interfaceexample;

public class Chicken extends Animal implements Eatable, Trainable{

	
	@Override
	public void makeSound() {
		System.out.println("Chicken sound");
		
	}

	@Override
	public void howToEat() {
		System.out.println("Make chicken soup...");
		
	}

	@Override
	public void howToTrain() {
		System.out.println("Chciken got trained.");
		
	}
	
}
