package example1;

public class Student {

}
