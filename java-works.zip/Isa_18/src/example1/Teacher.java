package example1;

public class Teacher {

}
