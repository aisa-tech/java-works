package example1;

public class GradStudent {

}
