
public class MainClass {

	public static void main(String[] args) {
		
		//Object instantiation
		Car car1 = new Car();
		
		car1.getInfo();
		
		car1.startEngine();
		car1.increaseSpeed(100);
		car1.stop();
		
		Car car2 = new Car(2, "White");
		
		car2.getInfo();
		
		car2.startEngine();
		car2.increaseSpeed(80);
		car2.stop();
		
		System.out.println("----------");
		
		Car car3 = new Car(4,"Black");
	
		System.out.println(car3.capacity);
		System.out.println(car3.color);
		car3.getInfo();
		car3.startEngine();
		
		System.out.println("----------");
		
		Car car4 = new Car(5, "red", true, 200);
		System.out.println("Started  : " + car4.started);
		System.out.println(car4.capacity);
		System.out.println(car4.speed);
		
		car4.getInfo();
		
		car4.startEngine();
	}
	
}
