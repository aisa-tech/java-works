
public class CalculatorMain {

	
	public static void main(String[] args) {
		
		Calculator calc = new Calculator();
		System.out.println(calc.makeDivision(3, 2));
		System.out.println(calc.makeDivision(4, 5));
		
		
	}
	
	
}
