
public class Calculator {

	
	double makeSum(double x, double y) {
		return x+y;
	}
	
	double makeDivision(double x, double y) {
		return x/y;
		
	}
	
	double makeSubtraction(double x, double y) {
		return x-y;
		
	}
	
	double makeMultiplication(double x, double y) {
		return x*y;
		
	}
	
}
