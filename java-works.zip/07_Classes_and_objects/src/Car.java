
public class Car {
	//State of the object
	//global variable
	//insta

	int capacity;
	String color;
	boolean started;
	double speed;
	
	//Default constructor
	// No param constructor
	Car() {
		System.out.println("Constructor call...");
		capacity = 5;
		color = "No color";
		
		
	}
	//Non-default constructor
	Car(int _capacity, String _color, boolean _started, double _speed) {
		System.out.println("Constructor call...");
		capacity = _capacity;
		color = _color;
		started = _started;
		speed = _speed;
		
		
	}
	
	//Another Non-default constructor
		Car(int _capacity, String _color) {
			System.out.println("Constructor call...");
			capacity = _capacity;
			color = _color;

			
			
		}
	
	
	//Behavour:
		
	void getInfo() {
		System.out.println("Capacity:" + capacity);
		System.out.println("Color:" + color);
		System.out.println("Speed"+ speed);
		System.out.println("Started"+ started);
	}
	
	void startEngine() {
		if(!started) {
			started = true;
			System.out.println("Car started");
		}
		else System.out.println("Car already started");
		
		
		
	}
	
	void increaseSpeed(double _speed) {
		if(started) {
			speed = _speed;
			System.out.println("Car speed is " + speed);
		}else System.out.println("Start the car first!");
	}
	
	void stop() {
		speed = 0;
		started = false;
		System.out.println("Car stopped..");
	}
	
}
