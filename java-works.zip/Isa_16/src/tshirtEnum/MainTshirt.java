package tshirtEnum;

public class MainTshirt {
	public static void main(String[] args) {
		
		Tshirt tshirt = new Tshirt(Tshirt.SIZES.LARGE);
		System.out.println(tshirt.getCost());
		System.out.println("---------");
		Tshirt thirt1 = new Tshirt(Tshirt.SIZES.SMALL);
		System.out.println(thirt1.getCost());
		
		
		
		
		
	}

}
