package tshirtEnum;

public class Tshirt {

	public enum SIZES{
		SMALL,MEDIUM,LARGE
	}

	
	private SIZES size;

	public Tshirt(SIZES size) {
		super();
		this.size = size;
	}
	
	public double getCost() {
		
		switch(size) {
		case SMALL:
			return 3.0;
		case MEDIUM:
			return 4.0;
		default :
			return 5.0;
		}
		
	}

}
