package tshirtEnum;

public enum SIZES {
	SMALL ,MEDIUM,LARGE
}
