package busses;

public enum  Destination {
	ANKARA, ISTANBUL

}
// enumda class yerine enum yaziyoruz.
//Suslu parantez icerisine buyuk harflerle degerler yazilir.
//