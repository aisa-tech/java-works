package busses;

public class Bus {
	private Destination destination;

	public Bus(Destination destination) {
		super();
		this.destination = destination;
	}
	
	public Destination getDestination() {
		return destination;
	}

}
