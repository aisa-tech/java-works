package tshirtExample;

public class MainTshirt {
	
	public static void main(String[] args) {
		
		Tshirt tshirt = new Tshirt(Tshirt.MEDIUM);
		Tshirt tshirt1 = new Tshirt(Tshirt.LARGE);
		System.out.println(tshirt.getCost());
		System.out.println(tshirt1.getCost());
		
		
		
	}

}
