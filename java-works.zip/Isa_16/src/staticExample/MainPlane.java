package staticExample;

public class MainPlane {
	
	public static void main(String[] args) {
		
		Plane plane1 = new Plane();
		Plane plane2 = new Plane();
		Plane plane3 = new Plane();
		Plane plane4 = new Plane();
		Plane plane5 = new Plane();
		
		System.out.println("Number of Planes : "+Plane.getCount());
		
	
		
		
	}

}
