package staticExample;

public class Plane {
	
	private static int count;
	
	public Plane() {
		count++;
		
		
	}
	
	public static int getCount() {
		return count;
	
	}
	
}
