package finalExample;

public class Calculator {

	public static final double PI=3.14;
	public final double START_NUMBER;
	
	public Calculator() {
		START_NUMBER = 300;
	}
	
	
	
}
