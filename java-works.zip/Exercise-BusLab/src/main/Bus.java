package main;

public class Bus {

	private Destination destination;
	private Passenger[] passengers = new Passenger[3];
	
	
	public Bus(Destination destination) {
		this.destination = destination;
	}
	
	
	public void insertPassenger(Passenger passenger) {
		boolean passengerInserted = false;
		
		if(destination == passenger.getDestination()) {
			
			for (int i = 0; i < passengers.length; i++) {
				if(passengers[i]==null) {
					passengers[i] = passenger;
					passengerInserted = true;
					break;
				}
			}
			
			
		}else {
			System.out.println("Destinations do not match");
			return;
		}
		
		if(passengerInserted) {
			System.out.println("Passenger inserted");
		}else {
			System.out.println("Bus is full");
		}
		
		
	}
	
	public Destination getDestination() {
		return destination;
	}
	public void setDestination(Destination destination) {
		this.destination = destination;
	}
	
	
	
}
