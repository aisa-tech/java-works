package main;

public class MainClass {
	
	public static void main(String[] args) {
		
		Passenger p1 = new Passenger("ahmet", Destination.ANKARA);
		Passenger p2 = new Passenger("altug", Destination.ISTANBUL);
		Passenger p3 = new Passenger("mehmet", Destination.ISTANBUL);
		Passenger p4 = new Passenger("osman", Destination.ANKARA);
		Passenger p5 = new Passenger("ayse", Destination.ANKARA);
		Passenger p6 = new Passenger("meltem", Destination.ANKARA);
		
		Bus bus = new Bus(Destination.ANKARA);
		
		
		bus.insertPassenger(p1);
		bus.insertPassenger(p2);
		bus.insertPassenger(p3);
		bus.insertPassenger(p4);
		bus.insertPassenger(p5);
		bus.insertPassenger(p6);
		
		
	}
	

}
