package main;

public enum Destination {

	ISTANBUL,ANKARA,IZMIR;
	
}
