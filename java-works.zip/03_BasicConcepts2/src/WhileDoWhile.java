import java.util.Scanner;

public class WhileDoWhile {

	
	public static void main(String[] args) {
		
		//while(A CONDITION){}
		
		
		int count = 0;
		
		//Below we create an infinite loop:
		/*
		 * while(true) {
		 * 
		 * }
		 */
		//While loop example
		/*
		 * while (count<101) { System.out.println(count); count++; }
		 */
		
		//Ask user for a character, and continue asking until a correct character is 
		//given (A-Z, a-z)
		
		
		//Type conversion:
		//We can convert primitive types to other primitive types
		// (TYPE)
		
		// double -> int i = 5; -> double d = (double)i;
		// python: float(), str(), int() 
		
		
		/*
		 * char A = 'A'; System.out.println((int)A); char Z = 'Z';
		 * System.out.println((int)Z); char a = 'a'; System.out.println((int)a); char z
		 * = 'z'; System.out.println((int)z);
		 */
		// if(c >='A' && c<='z')
		// All Strings in Java are actually arrays (lists)
		
		//String testStr = "a string";
		// testStr.charAt(0) -> returns the character of a specified index in a String
		
		/*
		int z = 0;
		while(z<100) {
			
		}
		*/
		
		Scanner sc = new Scanner(System.in);
		char input = '9';
		do {
			System.out.println("PLease enter a character:");
			input = sc.next().charAt(0);
			
		} while (!(input>='A' && input<='z'));
		
		
		System.out.println("Well done!");
		
	}
	
	
	
	
}
