
public class BreakAndContinue {
	
	public static void main(String[] args) {
		
		
		
		
		//break -> breaks the loop
		//continue -> skip the current and continue with the next value
		
		//break
		int i = 0;
		
		while(i<101) {
			
			if(i==50) break;
			System.out.println("i:" + i);
			i++;
		}
		
		System.out.println("out of the loop");
		
		
		//continue
		i = 0;
		
		while(i<101) {
			i++;
			if(i==50) continue;
			System.out.println("i:" + i);
			
		}
		
		System.out.println("out of the loop");
		
		
		
		
	}
	
	
	
	
	
}
