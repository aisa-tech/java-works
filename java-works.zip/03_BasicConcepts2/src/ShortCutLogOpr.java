
public class ShortCutLogOpr {

	public static void main(String[] args) {
		
		int x = 100;
		int y = 55;
		
		
		//&& ve || -> shortcut
		
		//true AND true
		//false AND true or false -> false
		if(x<50 && ++y>70) {
			
			System.out.println("OK");
			
			
		}else {
			System.out.println("Not ok");
		}
		
		System.out.println("y:"  + y);
		
		
		// | -> false then check the second cond
		// true or false
		//true or true
		
	}
	
	
	
	
}
