import java.util.Random;

public class NumberGuessGame {

	public static void main(String[] args) {
		
		// while or do while
		
		// Generate a random number -> number (0-100)
		//ask the user about the number -> guess
		// inform the user in each step number>guess higher! 
								//		number<guess lower!
		// The player has 10 steps maximum
		// display the number of steps left at each step
		// if the user cannot find the number, the user looses the game!
		
		
		//Random int numbers:
		//rnd.nextInt(bound) -> bound is exclusive
		Random rnd = new Random();
		int randNum = rnd.nextInt(100);
		System.out.println(randNum);
		
		
		
		
		
		
		
		
	}
	
	
	
	
	
}
