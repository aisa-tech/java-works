package overloading;

public class MainCalculator {
	
	public static void main(String[] args) {
		
		Calculator calculator = new Calculator();
		System.out.println(calculator.makeSum(1,6,4,2,24,45));
		
		
	}
	

}
