package com.main; 
public class Pen {
	//Overridden drawShape
	public void drawShape(Shape s){
		
			s.draw();

	}

	//Overridden changeColor
	public void changeColor(String color, Shape shape){
		shape.changeColor(color, shape);
		
	}

	
}
