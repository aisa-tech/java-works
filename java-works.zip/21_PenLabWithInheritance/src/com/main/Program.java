package com.main;

public class Program {

	public static void main(String[] args) {
		
		Circle circle 
		= new Circle("blue", 34);
		
		Rectangle rectangle 
		= new Rectangle("red",23,23);
		
		Pen pen = new Pen();
		
		pen.drawShape(circle);
		
		pen.drawShape(rectangle);
		
		pen.changeColor("red", circle);
		
		pen.changeColor("blue", rectangle);
		
		
	}
	
}
