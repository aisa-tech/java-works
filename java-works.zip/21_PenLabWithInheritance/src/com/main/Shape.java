package com.main;

public abstract class Shape {
	
	private String color;
	
	public Shape() {
		// TODO Auto-generated constructor stub
	}
	
	
	
	public Shape(String color) {
		super();
		this.color = color;
	}


	public abstract void draw();
	
	public void changeColor(String color, Shape shape) {
		shape.setColor(color);
		System.out.println(shape.getClass().getSimpleName() + " changed color to " + color);
	}

	public String getColor() {
		return color;
	}
	
	public void setColor(String color) {
		this.color = color;
	}

}
