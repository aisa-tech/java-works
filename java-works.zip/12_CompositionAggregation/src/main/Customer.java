package main;

public class Customer {

	//All the other info
	private String name;
	
	//Address
	private Address address;
	
	


	public Customer(String name, Address address) {
		this.name = name;
		this.address = address;
	}


	public String getInfo() {
		
		
		//Customer info
		
		return null;
	}
	
	

	public String getName() {
		return name;
	}




	public void setName(String name) {
		this.name = name;
	}




	public Address getAddress() {
		return address;
	}




	public void setAddress(Address address) {
		this.address = address;
	}
	
	
	
}
