package main;

public class CustomerMain {

	
	public static void main(String[] args) {
		
		
		Address address = new Address("istanbul", "120", "Bagdat St.","main");
		Customer cust1 = new Customer("altug", address);
		
		System.out.println(cust1.getName());
		System.out.println(cust1.getAddress().getCity());
		
	}
	
	
	
}
