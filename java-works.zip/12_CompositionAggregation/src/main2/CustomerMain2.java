package main2;

public class CustomerMain2 {

	
	public static void main(String[] args) {
		
		
		//initialization:
		Address workAdd = new Address("istanbul", "23", "Some st.", "Work");
		Address homeAdd = new Address("istanbul", "33", "Another st.", "Home");
		
		Address[] addresses = new Address[] {workAdd, homeAdd};
		
		
		Customer cust1 = new Customer("altug", addresses);
		
		System.out.println(cust1.getInfo());
		
		
		/* Old version
		System.out.println(cust1.getName());
		System.out.println("Addresses:");
		
		for (Address address : cust1.getAddresses()) {
			System.out.println("Type:" + address.getType());
			System.out.println(address.getCity());
			System.out.println(address.getNo());
		}
		*/
		
	}
	
	
	
}
