package main3;

public class Address {

	private String city;
	private String no;
	private String street;
	private String type;
	
	
	public Address() {
		// TODO Auto-generated constructor stub
	}


	public Address(String city, String no, String street, String type) {
		this.city = city;
		this.no = no;
		this.street = street;
		this.type = type;
	}

	
	public String getInfo() {
		return "Type: " + type + ", City:" + city + ", street:" + street + ", no:" + no;
	}

	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public String getNo() {
		return no;
	}


	public void setNo(String no) {
		this.no = no;
	}


	public String getStreet() {
		return street;
	}


	public void setStreet(String street) {
		this.street = street;
	}
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	
}
