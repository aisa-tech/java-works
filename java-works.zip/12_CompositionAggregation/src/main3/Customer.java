package main3;

import java.util.ArrayList;

public class Customer {

	//All the other info
	private String name;
	
	//Addresses
	private ArrayList<Address> addresses;
	
	


	public Customer(String name, ArrayList<Address> addresses) {
		this.name = name;
		this.addresses = addresses;
	}

	
	public String getInfo() {
		
		String retVal = "Customer:\n" + " name:" + name;
		retVal += "\nAddresses:";
		for (Address address : addresses) {
			retVal += address.getInfo() + "\n";
		}
		
		retVal+="\n------------";
		
		return retVal;
		
		
	}



	public String getName() {
		return name;
	}




	public void setName(String name) {
		this.name = name;
	}

	public ArrayList<Address> getAddresses() {
		return addresses;
	}
	
	public void setAddresses(ArrayList<Address> addresses) {
		this.addresses = addresses;
	}
	
	
}
