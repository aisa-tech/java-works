package main3;

import java.util.ArrayList;

public class ArrylistExample {

	
	public static void main(String[] args) {
		
		
		//I want to keep a list of names
		
		//For this task, we use the ArrayList type
		
		ArrayList<String> names = new ArrayList<String>();
		
		names.add("altug");
		names.add("ahmet");
		names.add("hayri");
		
		for (String name : names) {
			System.out.println(name);
		}
		
		System.out.println(names.get(0));
		
		names.remove(0);
		
		System.out.println("--------");
		
		for (String name : names) {
			System.out.println(name);
		}
		System.out.println("--------");
		ArrayList<String>name = new ArrayList<>();
		name.add("Isa");
		name.add("Yilmaz");
		name.add("Kerim");
		
		for (String string : name) {
			System.out.println(string);
			
		}
		System.out.println(name.get(0));
		System.out.println(name.remove(0));
		
		
		
		
		
	}
	
	
}
