import java.time.LocalDateTime;

public class Main {

	public static void main(String[] args) {
		
		Plane plane =new Plane(7005, "Pegasus", 99, 4300, "Cargo");
		
		LocalDateTime birthDate1 = LocalDateTime.of(1995, 7, 28, 13, 30);
		LocalDateTime jobStartDate1 = LocalDateTime.of(2018, 6, 24, 14, 00);
		
		LocalDateTime birthDate2 = LocalDateTime.of(1995, 5, 20, 13, 30);
		LocalDateTime jobStartDate2 = LocalDateTime.of(2017, 5, 24, 14, 00);
		
		
		
		Pilot pilot1 = new Pilot(2090, "Isa YILMAZ", birthDate1, jobStartDate1, "Primary");
		Pilot pilot2 =new Pilot(2004, "Kerim OZKAN", birthDate2, jobStartDate2, "Secondary");
		
		
		LocalDateTime departureTime = LocalDateTime.of(2020, 7, 28, 13, 30);
		LocalDateTime arrivalTime = LocalDateTime.of(2020, 7, 28, 17, 00);
		
		Pilot[] pilots = new Pilot[] {pilot1,pilot2};
		
		Flight flight = new Flight(4050, "Prag", "Istanbul", departureTime, arrivalTime, pilots, true, plane);
		
		
		System.out.println(flight.displayInformation());
		
		Pilot pilotNew = new Pilot(123, "a", birthDate1, jobStartDate1, "Primary");
		
		flight.reassignPilot(pilotNew);
		
		flight.cancelFlight();
		
		
		
	}
	
}
