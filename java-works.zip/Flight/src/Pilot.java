import java.time.LocalDateTime;

import javax.security.auth.callback.LanguageCallback;

public class Pilot {
	
	private long id;
	private String name;
	private LocalDateTime birthDate;
	private LocalDateTime jobStartDate;
	private String status;
	
	public Pilot() {
		// TODO Auto-generated constructor stub
	}

	public Pilot(long id, String name, LocalDateTime birthDate, LocalDateTime jobStartDate, String status) {
		super();
		this.id = id;
		this.name = name;
		this.birthDate = birthDate;
		this.jobStartDate = jobStartDate;
		this.status = status;
	}

	public int getExperienceYears() {
		int experience = LocalDateTime.now().getYear() - birthDate.getYear();
		return experience;
	}
	
	public int getAge() {
		int age = LocalDateTime.now().getYear()-birthDate.getYear();
		return age;
	}

	public String displayInformation() {
		String retval = "ID : " + id + "Name : " + name + "Age  :  " + getAge()+ "Experience :" + getExperienceYears() + "Sattus"+status;
		return retval;
	}

	
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public LocalDateTime getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(LocalDateTime birthDate) {
		this.birthDate = birthDate;
	}

	public LocalDateTime getJobStartDate() {
		return jobStartDate;
	}

	public void setJobStartDate(LocalDateTime jobStartDate) {
		this.jobStartDate = jobStartDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	
	
	
	

}
