import java.time.LocalDateTime;


public class Flight {
	
	private long id;
	private String destination;
	private String departure;
	private LocalDateTime departureTime;
	private LocalDateTime arrivalTime;
	private Pilot[] pilots;
	private boolean cancelled;
	private Plane plane;
	
	public Flight() {
		// TODO Auto-generated constructor stub
	}

	
	

	public Flight(long id, String destination, String departure, LocalDateTime departureTime, LocalDateTime arrivalTime,
			Pilot[] pilots, boolean cancelled, Plane plane) {
		super();
		this.id = id;
		this.destination = destination;
		this.departure = departure;
		this.departureTime = departureTime;
		this.arrivalTime = arrivalTime;
		this.pilots = pilots;
		this.cancelled = cancelled;
		this.plane = plane;
	}




	public void cancelFlight() {
		if(cancelled=true) {
			System.out.println("Flight cancelled");
		}else {
			System.out.println("Flight NOT cancelled");
		}
	
	}
	
	
	public void reassignPilot (Pilot pilotNew) {
		System.out.println("Pilot assigned -----------------");
		for (int i = 0; i < pilots.length; i++) {
			if(pilots[i].getStatus()==pilotNew.getStatus()) {
				pilots[i] = pilotNew;
				break;
			}
			
		}
		
	}
		
	public String displayInformation() {
		String info = "ID : " + id + "\nDestination : " + destination + "\nDeparture : "+ departure+"\nDepartureTime : "+ departureTime + "\nArrival TIME : " + arrivalTime; 
		info += plane.getName();
		for (Pilot pilot : pilots) {
			info += pilot.displayInformation();
		}
	return info;
	
	
	
	}
	

	
	
	
			
	
	
	
	
	
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getDeparture() {
		return departure;
	}

	public void setDeparture(String departure) {
		this.departure = departure;
	}

	public LocalDateTime getDepartureTime() {
		return departureTime;
	}

	public void setDepartureTime(LocalDateTime departureTime) {
		this.departureTime = departureTime;
	}

	public LocalDateTime getArrivalTime() {
		return arrivalTime;
	}

	public void setArrivalTime(LocalDateTime arrivalTime) {
		this.arrivalTime = arrivalTime;
	}

	public Pilot[] getPilots() {
		return pilots;
	}

	public void setPilots(Pilot[] pilots) {
		this.pilots = pilots;
	}

	public boolean isCancelled() {
		return cancelled;
	}

	public void setCancelled(boolean cancelled) {
		this.cancelled = cancelled;
	}
	
	

}
