package PenLab;

public class Pen {
	
	public void drawShape(Rectangle r) {
		System.out.println("Color is " + r.getColor()
		+"width is" + r.getWidth() 
		+"Height is" + r.getHeight());
		
	}
	public void drawShape(Circle c) {
		System.out.println("Color is "+c.getColor()
		+"Radious is "+c.getRadious());
	}
	
	public void changeColor(String color,Rectangle r) {
		r.setColor(color);
		System.out.println("Rectangle color changed to "+r.getColor());
		
	}
	public void changeColor(String color,Circle c) {
		c.setColor(color);
		System.out.println("Circle color change to " + c.getColor());
	}

}
