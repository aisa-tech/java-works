package PenLab;

public class Circle {
	
	private String color;
	private double radious;
	
	public Circle() {
		// TODO Auto-generated constructor stub
	}

	public Circle(String color, double radious) {
		super();
		this.color = color;
		this.radious = radious;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public double getRadious() {
		return radious;
	}

	public void setRadious(double radious) {
		this.radious = radious;
	}
	
	

}
