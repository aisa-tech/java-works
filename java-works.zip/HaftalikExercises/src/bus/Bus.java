package bus;

public class Bus {
	
	private Destination destination;
	private Passanger[] passangers = new Passanger[5];
	
	public Bus(Destination destination) {
		super();
		this.destination = destination;
	}

	public void insertPassanger(Passanger passanger) {
		boolean insertedPassanger = false;
		if(destination == passanger.getDestination()) {
			for (int i = 0; i < passangers.length; i++) {
				if(passangers[i]==null) {
					passangers[i] = passanger;
					insertedPassanger = true;
					break;
					
				}
				
			}
		}else {
			System.out.println("Destinations are not match .");
			return;
			
		}
		
		if (insertedPassanger) {
			System.out.println("Passanger inserted");
		}else {
			System.out.println("Bus is full.");
		}
	}
	

	
	public Destination getDestination() {
		return destination;
	}

	public void setDestination(Destination destination) {
		this.destination = destination;
	}
	
	

}
