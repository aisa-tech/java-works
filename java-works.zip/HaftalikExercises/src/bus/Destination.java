package bus;

public enum Destination {
	ISTANBUL, ANKARA,IZMIR,KRAKOW,PRAG
	
}
