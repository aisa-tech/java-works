package bus;

public class Main {
	
	public static void main(String[] args) {
		
		Passanger p1 = new Passanger("Isa",Destination.ANKARA);
		Passanger p2 = new Passanger("Yilmaz", Destination.ISTANBUL);
		Passanger p3 = new Passanger("Kerim", Destination.IZMIR);
		Passanger p4 = new Passanger("Isa",Destination.KRAKOW);
		Passanger p5 = new Passanger("Bunyo",Destination.ANKARA);
		Passanger p6 = new Passanger("Kerim", Destination.KRAKOW);
		Passanger p7 = new Passanger("Abdullah", Destination.IZMIR);
		Passanger p8 = new Passanger("Ahmet",Destination.KRAKOW);
		
		Bus bus = new Bus(Destination.KRAKOW);
		
		bus.insertPassanger(p1);
		bus.insertPassanger(p2);
		bus.insertPassanger(p3);
		bus.insertPassanger(p5);
		bus.insertPassanger(p6);
		bus.insertPassanger(p7);
		
		
		
		
		
		
		
		
		
		
	}

}
