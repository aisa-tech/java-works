package edu.sabanciuniv.model;

public class Teacher {

}
