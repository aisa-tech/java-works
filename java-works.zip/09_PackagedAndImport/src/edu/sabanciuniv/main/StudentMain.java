package edu.sabanciuniv.main;

import edu.sabanciuniv.model.*;

public class StudentMain {

	
	//Naming conventions of packages:
	// Company : Sabanci University
	// sabanciuniv.edu
	
	//an example package name (utils):
	// edu.sabanciuniv.utils
	// edu.sabanciuniv.model
	//edu.sabanciuniv.main
	
	
	public static void main(String[] args) {
		Student stu = new Student();
		
		Teacher t = new Teacher();
		
		
	}
	
	
}
