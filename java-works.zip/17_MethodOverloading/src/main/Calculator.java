package main;

import java.util.ArrayList;

public class Calculator {

	
	//Method signature: method name + list of parameters
	// ex: makeSum(double,double)
	public double makeSum(double num1 , double num2) {
		return num1+num2;
	}
	
	//Let's overload makeSum
	//Aşırı yükleme
	
	
	public double makeSum(double num1 , double num2, double num3) {
		
		return num1+num2+num3;
	}
	
	//Variable length parameter list
	//must be at the end of parameter list
	public double makeSum(double... nums) {
		 //nums = a double array
		double sum = 0;
		
		for (double d : nums) {
			sum+=d;
		}
		
		return sum;
		
	}
	
	
}
