package main;

public class MainClaculator {

	public static void main(String[] args) {
		
		Calculator calc = new Calculator();
		
		System.out.println(calc.makeSum(3,4,5,6,7));
		
		
		
		
		
		
		
	}
	
	
	
}
