
public class Champions {

	public static void main(String[] args) {
		
		//Please give an output matching each team once, ie:
		// Roma - Barcelona
		// Roma - Juventus
		// 
		
		String[] teams = {"Roma", "Barcelona", "Juventus", "Bayern Munich", 
		         "Sevilla", "Real Madrid", "Manchester City", "Liverpool"};
		for (int i = 0; i < teams.length; i++) {
			for (int j = i+1; j < teams.length; j++) {
				System.out.println(teams[i] + " - "  + teams[j]);
			}
		}
		
		
	}
	
	
	
	
}
