package asatype;

public class MainClass {

	public static void main(String[] args) {
		
		
		String s1 = new String("A new String...");
		
		String s2 = "Some more string..";
		
		
		AnImmutableType t1 = new AnImmutableType("test test test");
		
		
		s1+= " added String..";
		
	}
	
	
	
	
	
}
