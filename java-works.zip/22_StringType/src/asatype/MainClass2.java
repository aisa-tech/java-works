package asatype;

public class MainClass2 {

	
	public static void main(String[] args) {
		
		//String equality
		
		String s1 = "test";
		
		String s2 = "test";
		
		
		System.out.println(s1==s2);
		
		//when String constructor is called, String constant pool is not searched
		// and a new string is created at memory
		String s3 = new String("test");
		
		System.out.println(s2==s3);
		
		String javaStr = "Java rules!";
		
		
		String java1 = "Java ";
		String java2 = "rules!";
		
		String javaAll = java1+java2;
		
		System.out.println(javaStr == javaAll);
		
		
		//We use equals() method for String equality
		
		System.out.println(s2.equals(s3));
		System.out.println(javaStr.equals(javaAll));
		
		
		//In order to concatenate Strings we use StringBuilder (Post Java 5) 
		//or StringBuffer //Pre Java 5 types
		
		
		StringBuilder strBuilder = new StringBuilder("First line\n");
		strBuilder.append(" added String\n").append( "  more strings\n");
		strBuilder.append(" added added");
		
		System.out.println(strBuilder);
		System.out.println("----------------");
		String textToSplit = "one two three four five";
		
		String[] words = textToSplit.split(" ");
		
		for (String word : words) {
			System.out.println(word);
		}
		
	}
	
	
	
}
