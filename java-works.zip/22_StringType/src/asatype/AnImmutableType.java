package asatype;

public class AnImmutableType {

	private String value;
	
	
	public AnImmutableType() {
		// TODO Auto-generated constructor stub
	}


	public AnImmutableType(String value) {
		super();
		this.value = value;
	}
	
	public String getValue() {
		return value;
	}
	
	
	
	
}
